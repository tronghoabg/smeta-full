async function reqAPI(url, method, header, body) {
    let response = await fetch(
        url,
        {
            method: method,
            body: body,
            headers: header
        })

    let html = await response.text().then((res) => res)
    return html;
}
async function reqAPI2(url, method, urlencoded) {
    try {
        let response = await fetch(
            url,
            {
                method: method,
                body: urlencoded,
            })
        let html = await response.text().then((res) => res)
        return html;
    } catch (error) {
        return 'error_server'
    }
}

async function getToken() {
    let url0 = 'https://www.facebook.com/adsmanager/manage/campaigns'
    let url1 = 'https://business.facebook.com/adsmanager/manage/accounts';
    let url2 = 'https://business.facebook.com/adsmanager/manage/accounts?act='

    try {
        var json = await reqAPI(url0, 'GET');
        var flag = json.indexOf('__accessToken=')
        var token = 'NO'
        var fbdt = "NO"
    } catch (error) {
        return {
            "token": 'ERR',
            "fbdt": 'ERR'
        }
    }


    if (flag < 0) {
        json = await reqAPI(url1, 'GET');
        flag = json.indexOf('adAccountId: \\"')
        if (flag < 0) {
            var obj = {
                "token": token,
                "fbdt": fbdt
            }
            return obj;
        } else {
            accadsid = json.split('adAccountId: \\"')[1].split('\\"')[0];
            json = await reqAPI(url2 + accadsid, 'GET')
            token = json.split('window.__accessToken="')[1].split('"')[0];
            fbdt = json.split('["DTSGInitData",[],{"token":"')[1].split('"')[0]
        }
    } else {
        token = json.split('window.__accessToken="')[1].split('"')[0];
        fbdt = json.split('["DTSGInitData",[],{"token":"')[1].split('"')[0]
    }
    var obj = {
        "token": token,
        "fbdt": fbdt
    }
    return obj;
}


async function getTokenEAAG(idBm) {
    let url = 'https://business.facebook.com/settings/people/' + idBm + ' ?business_id=' + idBm;
    let json = await reqAPI(url, 'GET');
    let token = json.split('accessToken":"')[2].split('"')[0];;
    chrome.storage.local.set({ 'tokenEAAG': token })
    return token;
}

async function main(token, fbdt) {
    var user_id = await chrome.storage.local.get('user_id')
    user_id = user_id.user_id
    getListAccounts(token, user_id);
    getListBM(token, fbdt);
    getStatusFanPage(token, user_id);
}

async function getStatusFanPage(token, user_id) {
    let url = 'https://graph.facebook.com/v15.0/me?fields=accounts.limit(40){id,name,verification_status,is_published,ad_campaign,roles{id, tasks},is_promotable,is_restricted,parent_page,promotion_eligible,fan_count,followers_count,has_transitioned_to_new_page_experience,picture}&access_token=' + token;
    let json = await reqAPI(url, 'GET')
    let obj = JSON.parse(json);

    if ('accounts' in obj) {
        let objList = obj.accounts.data
        var tempNext = obj.accounts.paging
        while ('next' in tempNext) {
            var urlNext = tempNext.next
            json = await reqAPI(urlNext, 'GET')
            obj = JSON.parse(json);
            objList = objList.concat(obj.data)
            tempNext = obj.paging
        }
        var arrFan = [];
        for (const [index, fan] of objList.entries()) {
            var objFan = {
                stt: 0,
                img: null,
                id: null,
                name: null,
                status: null,
                likecount: null,
                followers: null,
                role: null,
                promotable: null,
                ads: null,
            }
            objFan.stt = index + 1
            for (var f in fan) {
                switch (f) {
                    case 'picture':
                        url = fan[f]['data']['url']
                        objFan.img = url;
                        break;
                    case 'id':
                        objFan.id = fan[f];
                        break;
                    case 'name':
                        objFan.name = fan[f];
                        break;
                    case 'verification_status':
                        objFan.status = fan[f];
                        break;
                    case 'fan_count':
                        objFan.likecount = fan[f];
                        break;
                    case 'followers_count':
                        objFan.followers = fan[f];
                        break;
                    case 'roles':
                        let arrRole = fan[f].data
                        let obj = arrRole.find(obj => obj.id === user_id);
                        if (!obj) {
                            objFan.role = '-';
                            break;
                        }
                        if (obj.tasks.includes('CREATE_CONTENT')) {
                            objFan.role = 'true';
                        } else {
                            objFan.role = '-';
                        }
                        break;
                    case 'is_promotable':
                        objFan.promotable = fan[f];
                        break;
                    case 'ads_posts':
                        objFan.ads = fan[f]['data'].length;
                        break;
                    default:
                        objFan.ads = 0;
                }
            }
            arrFan.push(objFan)
        }
    } else {
        var tableBM = document.getElementById('tbFanPage');
        tableBM.innerHTML = '<p>....</p>'
        var arrFan = []
    }
    chrome.storage.local.set({ 'objFan': JSON.stringify(arrFan) });
    renderHtmlFan(arrFan);
}

function renderHtmlFan(arrObj) {
    var tableFan = document.getElementById('tbFanPage');
    if (arrObj.length == 0) {
        tableFan.innerHTML = '<p>....</p>'
        clearloadData('.loaddata3')
        return
    }
    var result = ''
    tableFan.innerHTML = result
    let html = arrObj.map(function (arr) {
        result += `<tr class="trInfo">`
        for (var a in arr) {
            if (a == 'img') {
                result += `<td class="tdInfo"><img src=${arr[a]}></img></td>`
            } else if (a == 'id') {
                result += `<td class="tdInfo"><a href="#" title="Tới Fanpage" class="link-ads" type="fan">${arr[a]}</a></td>`
            } else if (a == 'status') {
                if (arr[a] == 'not_verified') {
                    result += `<td class="tdInfo"><i class="fa-solid fa-circle-check fa-sm" style="color: #797a7c;"></i></td>`
                } else {
                    result += `<td class="tdInfo"><i class="fa-solid fa-circle-check fa-sm" style="color: #067edb;"></i></td>`
                }
            } else {
                result += `<td class="tdInfo">${arr[a]}</td>`
            }
        }
        result += `</tr">`
    })
    tableFan.innerHTML += result;
    clearloadData('.loaddata3')
}

function renderHtmlCamp(arrObj) {
    var tableCamp = document.getElementById('tbCamp');
    if (arrObj.length == 0) {
        return
    }
    var result = ''
    let html = arrObj.map(function (arr) {
        result += `<tr class="trInfo">`
        for (var a in arr) {
            txt = arr[a]
            if (a == 'campaign_name') {
                txt = txt.slice(0, 20)
            }
            result += `<td class="tdInfo">${txt}</td>`
        }
        result += `</tr">`
    })
    tableCamp.innerHTML += result;
    clearloadData('.loaddata4')
}


async function getListBM(token, fbdt) {
    var arrBM = [];
    var url = 'https://graph.facebook.com/v15.0/me/businesses?fields=id,created_time,is_disabled_for_integrity_reasons,sharing_eligibility_status,allow_page_management_in_www,can_use_extended_credit,name,timezone_id,timezone_offset_hours_utc,verification_status,owned_ad_accounts{id,currency,timezone_offset_hours_utc,timezone_name}&access_token=' + token;
    var json = await reqAPI(url, 'GET')
    var obj = JSON.parse(json);
    var tempNext = obj.paging
    var objList = obj.data
    if (objList.length == 0) {
        chrome.storage.local.set({ 'objBM': JSON.stringify(arrBM) });
        clearloadData('.loaddata2')
        return
    }
    while ('next' in tempNext) {
        var urlNext = tempNext.next
        json = await reqAPI(urlNext, 'GET')
        obj = JSON.parse(json);
        objList = objList.concat(obj.data)
        tempNext = obj.paging
    }

    for (const [index, bm] of objList.entries()) {
        var objBM = {
            s_stt: 0,
            s_status: null,
            s_id: null,
            s_name: null,
            s_levelBm: 'loading...',
            s_admin: 'loading...',
            s_limit: null,
            s_timezone: null,
            s_datecreate: null,

        };
        objBM.s_stt = index + 1
        for (var info in bm) {
            switch (info) {
                case 'id':
                    objBM.s_id = bm[info];
                    break;
                case 'name':
                    objBM.s_name = bm[info];
                    break;
                case 'allow_page_management_in_www':
                    if (bm[info]) {
                        objBM.s_status = "Live"
                    } else {
                        objBM.s_status = "Die"
                    }
                    break;
                case 'can_use_extended_credit':
                    if (bm[info]) {
                        objBM.s_limit = '250';
                    } else {
                        objBM.s_limit = bm[info];
                    }
                    break;
                case 'timezone_id':
                    objBM.s_timezone = bm[info] + ' : ' + objTimeZone[bm[info]];
                    break;
                case 'created_time':
                    objBM.s_datecreate = bm[info].slice(0, 10);
                    break;
            }
        }
        renderBM(objBM)
        arrBM.push(objBM)
    }
    chrome.storage.local.set({ 'objBM': JSON.stringify(arrBM) });
    var tokenEAAG = await getTokenEAAG(arrBM[0]['s_id']);
    var fetches = []
    for (var b of arrBM) {
        let idbm = b['s_id'];
        fetches.push(getBmlimit(idbm, fbdt, arrBM))
        fetches.push(CheckAdminHide(idbm, token, tokenEAAG, arrBM))
    }
    clearloadData('.loaddata2')
    await Promise.all(fetches).then(function (obj) {
    })
    handlerEventTable();
}

async function renderBM(obj) {
    var tb = document.getElementById('tbBM')
    var selectBM = document.getElementById('listBM');
    var result = '';
    var line_html = ''
    for (var e in obj) {
        if (e.slice(0, 2) == 's_') {
            switch (e) {
                case 's_id':
                    listBM = `<option>${obj[e]}</option>`
                    line_html += `<td class="tdInfo"><a href="#" title="Tới trang cài đặt doanh nghiệp" class="link-ads" type="bm">${obj[e]}</a></td>`
                    break
                case 's_levelBm':
                    line_html += `<td class="tdInfo" id="${obj['s_id']}_LV">${obj[e]}</td>`
                    break
                case 's_admin':
                    line_html += `<td class="tdInfo" id="${obj['s_id']}_adminhide"><span>${obj[e]}</span></td>`
                    break
                default:
                    line_html += `<td class="tdInfo">${obj[e]}</td>`
                    break
            }
        }
    }
    result = `<tr class="trInfo">${line_html}</tr">`
    tb.innerHTML += result
    selectBM.innerHTML += listBM;
}

function renderHtmlBM(arrObj) {
    var tb = document.getElementById('tbBM')
    var selectBM = document.getElementById('listBM');
    if (arrObj.length == 0) {
        tb.innerHTML = '<p>....</p>'
        clearloadData('.loaddata2')
        return
    }
    var result = ''
    let html = arrObj.map(function (obj) {
        var line_html = ''
        for (var e in obj) {
            if (e.slice(0, 2) == 's_') {
                switch (e) {
                    case 's_id':
                        listBM += `<option>${obj[e]}</option>`
                        line_html += `<td class="tdInfo"><a href="#" title="Tới trang cài đặt doanh nghiệp" class="link-ads" type="bm">${obj[e]}</a></td>`
                        break
                    case 's_levelBm':
                        line_html += `<td class="tdInfo" id="${obj['s_id']}_LV">${obj[e]}</td>`
                        break
                    case 's_admin':
                        line_html += `<td class="tdInfo" id="${obj['s_id']}_adminhide"><div class="tbadminshow"><span>${obj[e]}</span><i class="fa-solid fa-user-pen fa-sm show-admin" title="Xem và xóa admin ẩn"  data-type="bm" data-id="${obj['s_id']}"></i></div></td>`
                        break
                    default:
                        line_html += `<td class="tdInfo">${obj[e]}</td>`
                        break
                }
            }
        }
        result += `<tr class="trInfo">${line_html}</tr>`
    })

    tb.innerHTML = result
    selectBM.innerHTML = listBM;
    clearloadData('.loaddata2')
}



async function getBmlimit(idBm, fbdt, arr) {
    let url = 'https://business.facebook.com/business/adaccount/limits/?business_id=' + idBm + '&__a=1&fb_dtsg=' + fbdt;
    let json = await reqAPI(url, 'POST')
    var levelBM = '-'
    try {
        let bmLimit = json.split('adAccountLimit":')[1].split('}')[0];
        levelBM = bmLimit
    } catch { }
    let element = document.getElementById(idBm + '_LV')
    element.innerHTML = levelBM

    let index = arr.findIndex(element => element.s_id == idBm)
    arr[index].s_levelBm = levelBM
    chrome.storage.local.set({ 'objBM': JSON.stringify(arr) });
}


async function CheckAdminHide(idbm, token, tokenEAAG, arr) {
    let countAdminEAAG = await CheckAdminhideEAAG(idbm, tokenEAAG, arr)
    let countAdminEAAB = await CheckAdminhideEAAB(idbm, token, arr)
    var countAdminHide = countAdminEAAB - countAdminEAAG
    let result = `${countAdminEAAB} (${countAdminHide})`
    let element = document.getElementById(idbm + '_adminhide')
    element.innerHTML = `<div class="tbadminshow"><span>${result}</span><i class="fa-solid fa-user-pen fa-sm show-admin" title="Xem và xóa admin"  data-type="bm" data-id="${idbm}"></i></div>`

    let index = arr.findIndex(element => element.s_id == idbm)
    arr[index].s_admin = result
    chrome.storage.local.set({ 'objBM': JSON.stringify(arr) });
}

async function CheckAdminhideEAAG(idbm, tokenEAAG, arr) {
    let url = 'https://graph.facebook.com/v14.0/' + idbm + '/business_users?access_token=' + tokenEAAG + '&fields=id'
    let json = await reqAPI(url, 'GET')
    let obj = JSON.parse(json);
    let objList = obj.data
    return objList.length;
}

async function CheckAdminhideEAAB(idbm, token, arr) {
    let url = 'https://graph.facebook.com/v14.0/' + idbm + '/business_users?access_token=' + token + '&fields=id'
    let json = await reqAPI(url, 'GET')
    let obj = JSON.parse(json);
    let objList = obj.data
    return objList.length;
}


/// Share TKQC
async function ShareAdAcc(token, adacc, user_id, role, log) {
    result = ''
    var url = `https://adsmanager-graph.facebook.com/v15.0/act_${adacc}/users?access_token=${token}`
    let formData = new FormData();
    formData.append('account_id', adacc);
    formData.append('uid', user_id);
    formData.append('role', role);
    let response = await reqAPI(url, 'POST', {}, formData)
    let obj = JSON.parse(response)
    try {
        if ('error' in obj) {
            result = `${adacc} -> ${user_id}: ${(obj.error.error_user_title ? obj.error.error_user_title : obj.error.message)}`
        }
        if ('success' in obj) {
            result = `${adacc} -> ${user_id}: Share thành công`
        }
    } catch (error) {
        result = `${adacc} -> ${user_id}: Sảy ra lỗi`
    }
    log.innerHTML += `<li>${result}</li>`
}

/// hàm Share Pixel
async function SharePixel(token, idBm, idPixel, idAds) {
    url = "https://graph.facebook.com/v15.0/" + idPixel + "/shared_accounts"
    let formData = new FormData();
    formData.append('account_id', idAds);
    formData.append('business', idBm);
    formData.append('access_token', token);
    let response = await reqAPI(url, 'POST', {}, formData)
    let obj = JSON.parse(response);

    if (obj['success']) {
        chrome.logHtml += `<li>${idAds} : ${obj['success']}</li>`
    } else if (obj['error_user_msg']) {

    } else {
        chrome.logHtml += `<li> ${idAds} : ${obj['error']['message']}</li>`
    }
    var logHtml = document.getElementById('logsatusSharePixel');
    logHtml.innerHTML = chrome.logHtml;
}

function renderCampaign(obj) {
    clearloadData('.loaddata4')
    var tb = document.getElementById('tbCamp')
    var result = '';
    var line_html = ''
    for (var e in obj) {
        txt = obj[e]
        if (e == 'campaign_name') {
            txt = txt.slice(0, 20)
        }
        line_html += `<td class="tdInfo">${txt}</td>`
    }
    result = `<tr class="trInfo">${line_html}</tr>`
    tb.innerHTML += result
}

async function getCampaign(acc, token) {
    clearloadData('.loaddata4')
    var url0 = 'https://graph.facebook.com/v15.0/' + acc + '/campaigns?date_preset=last_90d&fields=id,status,daily_budget,lifetime_budget,start_time,end_time&access_token=' + token
    var json0 = await reqAPI(url0, 'GET')
    var obj0 = JSON.parse(json0);
    if ('data' in obj0) {
        var objBudget = obj0.data
    }
    var url = 'https://graph.facebook.com/v15.0/' + acc + '/insights?date_preset=last_90d&level=adset&fields=account_id,campaign_id,campaign_name,impressions,ctr,cpc,cpm,spend,account_currency,clicks,conversions,actions,converted_product_quantity&access_token=' + token
    var json = await reqAPI(url, 'GET')
    var obj = JSON.parse(json);
    var arrCamp = []
    if ('data' in obj) {
        objCampaign = obj.data
        if (objCampaign.length < 1) {
            return
        }
        for (let camp of objCampaign) {
            var objCamp = {
                account_id: '.' + acc,
                status: '',
                campaign_name: '',
                impressions: '',
                clicks: '',
                cpm: '',
                cpc: '',
                ctr: '',
                spend: '',
                lifetime_budget: '',
                account_currency: '',
                start_time: '',
                stop_time: '',
            }

            for (var e in objCamp) {
                switch (e) {
                    case 'status':
                        for (let objbig of objBudget) {
                            if (camp.campaign_id == objbig.id) {
                                objCamp[e] = objbig.status
                                break
                            }
                        }
                        break
                    case 'lifetime_budget':
                        for (let objbig of objBudget) {
                            if (camp.campaign_id == objbig.id) {
                                objCamp[e] = objbig.lifetime_budget
                                break
                            }
                        }
                        break
                    case 'start_time':
                        for (let objbig of objBudget) {
                            if (camp.campaign_id == objbig.id) {
                                objCamp[e] = objbig.start_time.slice(0, 10)
                                break
                            }
                        }
                        break
                    case 'stop_time':
                        for (let objbig of objBudget) {
                            if (camp.campaign_id == objbig.id && (e in objbig)) {
                                objCamp[e] = objbig.stop_time.slice(0, 10)
                                break
                            }
                        }
                        break
                    case 'cpm':
                        objCamp[e] = Number(camp[e]).toFixed(2)
                        break
                    case 'cpc':
                        objCamp[e] = Number(camp[e]).toFixed(2)
                        break
                    case 'ctr':
                        objCamp[e] = Number(camp[e]).toFixed(2)
                        break

                    default:
                        objCamp[e] = camp[e]
                }

            }
            renderCampaign(objCamp)
            arrCamp.push(objCamp)
        }
    }
    tempObj = await chrome.storage.local.get(['objCamp']);
    tempObj = JSON.parse(tempObj.objCamp)
    tempObj.push(...arrCamp)
    chrome.storage.local.set({ 'objCamp': JSON.stringify(tempObj) });
}

async function getPayment(act, fbdt) {
    let objPayment = await getCard(act, fbdt)
    let bills = await getBills(objPayment.id, fbdt)
    var tempObj = await chrome.storage.local.get(['objPayment']);
    tempObj = tempObj.objPayment
    obj = {
        'act': act,
        'payments': objPayment.payment,
        'bills': bills
    }
    return obj
}

async function getBills(act, fbdt) {
    url = 'https://business.facebook.com/api/graphql/'
    let formData = new FormData();
    formData.append('fb_dtsg', `${fbdt}`);
    formData.append('variables', `{"count":20,"cursor":null,"end_time":${Math.round(+new Date() / 1000)},"filters":[],"start_time":1339261200,"id":"${act}"}`);
    formData.append('doc_id', '5088279497901543');
    let response = await fetch(url, {
        method: 'post',
        credentials: 'include',
        mode: "cors",
        body: formData,
        headers: {
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site"
        },
    })
    let html = await response.text().then((res) => res)
    let objJson = JSON.parse(html)
    var objData = {}
    let txt_bill = ''
    try {
        objData = objJson['data']['node']['billing_txns']['edges']
        if (objData.length > 0) {
            var count_paid = 0
            var count_faild = 0
            for (var bills of objData) {
                let objBill = bills.node
                txt_bill += (objBill.status == 'COMPLETED' ? '✓ PAID' : objBill.status) + ' | ' + objBill.payment_method_label + ' | ' + ' | ' + new Date(objBill.transaction_time * 1000).toLocaleDateString("en-US") + ' | ' + objBill.total_amount.formatted_amount + '\n'
                if (objBill.status == 'COMPLETED') {
                    count_paid++
                } else {
                    count_faild++
                }
            }
            txt_bill = `( ${objData.length} Bills gần nhất | Paid: ${count_paid} | Faild: ${count_faild} ) Export by sMeta.vn* \n ${txt_bill}`
        }
    } catch (ex) {
        if ('errors' in objJson) {
            txt_bill = objJson['errors'][0]['message']
        }
    }
    return txt_bill
}

async function getCard(act, fbdt) {
    url = 'https://business.facebook.com/api/graphql/'
    let formData = new FormData();
    formData.append('variables', `{"paymentAccountID":"${act}"}`);
    formData.append('doc_id', '5369940383036972');
    formData.append('fb_dtsg', fbdt);

    let response = await fetch(url, {
        method: 'post',
        credentials: 'include',
        mode: "cors",
        body: formData,
        headers: {
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site"
        },
    })
    let html = await response.text().then((res) => res)
    let objJson = JSON.parse(html)
    var listCard = ''
    var id_act = ''
    var obj = {}
    if ('data' in objJson) {
        let objCard = ''
        try {
            id_act = objJson['data']['billable_account_by_payment_account']['billing_payment_account']['id']
            objCard = objJson['data']['billable_account_by_payment_account']['billing_payment_account']['billing_payment_methods']
        } catch (e) {
            obj = {
                id: act,
                payment: listCard
            }
            return obj
        }
        for (var card of objCard) {
            var usability = card['usability']
            switch (usability) {
                case ("USABLE"):
                    usability = 'Usable'
                    break
                case 'UNVERIFIED_OR_PENDING_AUTH':
                    usability = 'Need'
                    break;
                case 'UNVERIFIABLE':
                    usability = 'Unverifiable'
                    break;
                case 'ADS_PAYMENTS_RESTRICTED':
                    usability = 'Restricted'
                    break;
            }
            card = card['credential']
            if (card['__typename'] == 'ExternalCreditCard') {
                listCard += card['card_association_name'] + ' ' + card['last_four_digits'] + ': ' + usability + ' | Expires on: ' + card['expiry_month'] + '/' + card['expiry_year'] + '\n'
            } else if (card['__typename'] == 'DirectDebit') {
                listCard += 'Banking(DirectDebit): ' + usability + '\n '
            } else if (card['__typename'] == 'AdsToken' || card['__typename'] == 'StoredBalance') {

            } else {
                listCard += '(' + card['__typename'] + ': ' + usability + '\n '
            }
        }
    } else if ('errors' in objJson) {
        listCard = objJson['errors'][0]['message']
        obj = {
            id: act,
            payment: listCard
        }
        return obj
    }
    obj = {
        id: id_act,
        payment: (listCard.indexOf('\n') ? listCard.slice(0, listCard.length - 1) : listCard)
    }
    return obj
}

async function getListCampaign() {
    var objTemp = await chrome.storage.local.get(['objAds', 'token', 'objCamp'])
    var token = objTemp.token
    objAds = JSON.parse(objTemp.objAds)
    objCamp = JSON.parse(objTemp.objCamp)
    if (objCamp.length > 0) {
        return
    }
    for (var acc of objAds) {
        getCampaign('act_' + acc.s_id, token)
    }
}


async function getListAccounts(token, user_id) {
    let url = `https://graph.facebook.com/v15.0/me/adaccounts?fields=account_id,owner_business,name,disable_reason,account_status,currency,adspaymentcycle,account_currency_ratio_to_usd,adtrust_dsl,balance,all_payment_methods{pm_credit_card{display_string,exp_month,exp_year,is_verified}},created_time,next_bill_date,timezone_name,amount_spent,timezone_offset_hours_utc,insights.date_preset(maximum){spend},userpermissions{user,role},owner,is_prepay_account,spend_cap&summary=true&limit=100&access_token=` + token;
    let res = await reqAPI(url, 'GET')
    var json = JSON.parse(res);
    if ('error' in json) {
        url = url.replace(/,is_prepay_account/g, '')
        res = await reqAPI(url, 'GET')
        json = JSON.parse(res);
    }
    if ('error' in json) {
        url = url.replace(/,all_payment_methods{pm_credit_card{display_string,exp_month,exp_year,is_verified}}/g, '')
        res = await reqAPI(url, 'GET')
        json = JSON.parse(res);
    }
    let objListACC = json.data
    var tempNext = json.paging
    while ('next' in tempNext) {
        var urlNext = tempNext.next
        json = await reqAPI(urlNext, 'GET')
        obj = JSON.parse(json);
        objListACC = objListACC.concat(obj.data)
        tempNext = obj.paging
    }
    var arrAcc = []
    var arrCamp = []
    chrome.storage.local.set({ 'objCamp': JSON.stringify(arrCamp) });
    for (const [index, acc] of objListACC.entries()) {
        var objAcc = {
            s_stt: 0,
            s_status: '',
            s_id: 'null',
            s_name: '',
            s_balance: '',
            s_threshold: '*',
            s_adtrust: '',
            s_spent: '',
            s_admin: '',
            s_currency: '',
            s_acctype: '',
            h_balance: '',
            h_threshold: '*',
            h_adtrust: '',
            h_spent: '',
            h_rate: '',
            s_role: '',
            s_bm: '',
            s_card: '',
            s_timezone: ''
        }
        usd_rate = acc.account_currency_ratio_to_usd
        objAcc.h_rate = usd_rate
        objAcc.s_stt = index + 1
        objAcc.s_status = getStatusAcc(acc.account_status)
        objAcc.s_id = acc.account_id
        objAcc.s_name = acc.name
        objAcc.s_balance = coverCurrency(acc.balance, acc.currency)
        if (acc.adspaymentcycle) {
            let threshold = acc.adspaymentcycle.data[0].threshold_amount
            threshold = coverCurrency(threshold, acc.currency)
            objAcc.s_threshold = threshold
        } else {
            objAcc.s_threshold = '-'
        }
        objAcc.s_adtrust = ((acc.adtrust_dsl == -1) ? 'No limit' : coverCurrency(acc.adtrust_dsl, 'round'))
        let spend = (acc.insights ? acc.insights.data[0].spend : 0)
        objAcc.s_spent = coverCurrency(spend, 'round')
        let arryUser = acc.userpermissions['data']
        var countAdminHide = 0
        arryUser.map((obj) => {
            if (!('user' in obj)) {
                countAdminHide++
            }
        })
        objAcc.s_admin = `${arryUser.length} (${countAdminHide})`
        objAcc.s_currency = acc.currency
        objAcc.s_acctype = (acc.owner_business ? 'BM' : 'CN')
        if (!acc.owner_business) {
            objAcc.s_acctype = 'CN'
        } else {
            objAcc.s_acctype = 'BM'
        }

        objAcc.h_balance = coverCurrency(objAcc.s_balance / usd_rate, 'round')
        objAcc.h_threshold = (!isNaN(objAcc.s_threshold)) ? coverCurrency((objAcc.s_threshold / usd_rate), 'round') : '-'
        objAcc.h_adtrust = objAcc.s_adtrust != 'No limit' ? coverCurrency((objAcc.s_adtrust / usd_rate), 'round') : 'No Limit'
        objAcc.h_spent = coverCurrency((objAcc.s_spent / usd_rate), 'round')
        var objRole = acc.userpermissions.data
        var role = ''
        for (var member of objRole) {
            var id = (member.user) ? member.user.id : 'none'
            if (id == user_id) {
                switch (member.role) {
                    case 'ADMIN':
                        role = 'Quản trị viên'
                        break
                    case 'REPORTS_ONLY':
                        role = 'Nhà phân tích'
                        break
                    case 'GENERAL_USER':
                        role = 'Nhà quảng cáo'
                        break
                    default:
                        role = member.role
                }
                break
            }
        }
        objAcc.s_role = role;
        objAcc.s_bm = (acc.owner_business ? acc.owner_business.id : '')
        var card = ''
        if (acc.is_prepay_account) {
            card = 'Trả Trước'
        } else if (acc.all_payment_methods) {
            var cardInfo = acc.all_payment_methods.pm_credit_card.data[0]
            card = `${cardInfo.display_string} (${cardInfo.exp_month}/${cardInfo.exp_year})`
        }
        objAcc.s_timezone = `${(acc.timezone_offset_hours_utc < 0) ? acc.timezone_offset_hours_utc : `+${acc.timezone_offset_hours_utc}`} | ${acc.timezone_name}`
        objAcc.s_card = card
        renderHtmlElementAcc(objAcc)
        arrAcc.push(objAcc);
    }
    chrome.storage.local.set({ 'objAds': JSON.stringify(arrAcc) });
}

function renderHtmlElementAcc(obj) {
    var tb = document.getElementById('tb');
    var result = '';
    var line_html = '';
    for (var e in obj) {
        if (e.slice(0, 2) == 's_') {
            var index = Object.keys(obj).indexOf(e)
            if (index == 2) {
                line_html += `<td class="tdInfo">
                    <a class="link-ads" type="ad" title="Tới trang quản lý chiến dịch" href="#" data="${obj.s_id}"><i class="fa-solid fa-chart-simple"></i>
                    </a>
                    <a class="link-ads" type="bill" title="Tới trang thanh toán" href="#" data="${obj.s_id}"><i class="fa-solid fa-coins"></i></a>
                    </td>`
            }
            switch (e) {
                case 's_status':
                    line_html += `<td class="tdInfo"><div class="tbstatus">${getStatusAccRender(obj[e])}${obj[e]}</div></td>`
                    break
                case 's_balance':
                    line_html += `<td class="tdInfo"><span class="r" value="${obj[e]}">${mony(obj[e])}</span><span class="g" value="${obj['h_balance']}">${mony(obj['h_balance'])}</span></td>`
                    break
                case 's_adtrust':
                    line_html += `<td class="tdInfo"><span class="r" value="${obj[e]}">${mony(obj[e])}</span><span class="g" value="${obj['h_adtrust']}">${mony(obj['h_adtrust'])}</span></td>`
                    break
                case 's_spent':
                    line_html += `<td class="tdInfo"><span class="r" value="${obj[e]}">${mony(obj[e])}</span><span class="g" value="${obj['h_spent']}">${mony(obj['h_spent'])}</span></td>`
                    break
                case 's_threshold':
                    line_html += `<td class="tdInfo"><span class="r" value="${obj[e]}">${mony(obj[e])}</span><span class="g" value="${obj['h_threshold']}">${mony(obj['h_threshold'])}</span></td>`
                    break
                case 's_admin':
                    line_html += `<td class="tdInfo">
                            <div class="tbadminshow"><span>${obj[e]}</span>
                            <i class="fa-solid fa-user-pen fa-sm show-admin" title="Xem và xóa admin ẩn" data-type="ad" data-bemo="${obj['s_bm']}" data-id="${obj['s_id']}"></i>
                            </div>
                            </td>`
                    break
                default:
                    line_html += `<td class="tdInfo">${obj[e]}</td>`
            }
        }
    }
    result += `<tr class="trInfo">${line_html}</tr>`

    tb.innerHTML += result;
    clearloadData('.loaddata1')
}

function renderHtmlAcc(arrObj) {
    var tb = document.getElementById('tb');
    if (arrObj.length == 0) {
        tb.innerHTML = '<p>No Ads Account</p>'
        return
    }
    var result = '';
    var line_html = '';
    let html = arrObj.map(function (obj) {
        var line_html = '';
        for (var e in obj) {
            if (e.slice(0, 2) == 's_') {
                var index = Object.keys(obj).indexOf(e)
                if (index == 2) {
                    line_html += `<td class="tdInfo">
                    <a class="link-ads" type="ad" title="Tới trang quản lý chiến dịch" href="#" data="${obj.s_id}"><i class="fa-solid fa-chart-simple"></i>
                    </a>
                    <a class="link-ads" type="bill" title="Tới trang thanh toán" href="#" data="${obj.s_id}"><i class="fa-solid fa-coins"></i></a>
                    </td>`
                }
                switch (e) {
                    case 's_status':
                        line_html += `<td class="tdInfo"><div class="tbstatus">${getStatusAccRender(obj[e])}${obj[e]}</div></td>`
                        break
                    case 's_balance':
                        line_html += `<td class="tdInfo"><span class="r" value="${obj[e]}">${mony(obj[e])}</span><span class="g" value="${obj['h_balance']}">${mony(obj['h_balance'])}</span></td>`
                        break
                    case 's_adtrust':
                        line_html += `<td class="tdInfo"><span class="r" value="${obj[e]}">${mony(obj[e])}</span><span class="g" value="${obj['h_adtrust']}">${mony(obj['h_adtrust'])}</span></td>`
                        break
                    case 's_spent':
                        line_html += `<td class="tdInfo"><span class="r" value="${obj[e]}">${mony(obj[e])}</span><span class="g" value="${obj['h_spent']}">${mony(obj['h_spent'])}</span></td>`
                        break
                    case 's_threshold':
                        line_html += `<td class="tdInfo"><span class="r" value="${obj[e]}">${mony(obj[e])}</span><span class="g" value="${obj['h_threshold']}">${mony(obj['h_threshold'])}</span></td>`
                        break
                    case 's_admin':
                        line_html += `<td class="tdInfo">
                            <div class="tbadminshow"><span>${obj[e]}</span>
                            <i class="fa-solid fa-user-pen fa-sm show-admin" title="Xem và xóa admin ẩn" data-type="ad" data-bemo="${obj['s_bm']}" data-id="${obj['s_id']}"></i>
                            </div>
                            </td>`
                        break
                    default:
                        line_html += `<td class="tdInfo">${obj[e]}</td>`
                }
            }
        }
        result += `<tr class="trInfo">${line_html}</tr>`
    })
    tb.innerHTML = result;
    clearloadData('.loaddata1')
}

async function getDraftId(act, bm) {
    var draft_id = 'error'
    var url = `https://adsmanager.facebook.com/adsmanager/manage/campaigns?act=${act}`
    if (bm != '') {
        url += `&business_id=${bm}&nav_source=no_referrer`
    }
    let res = await reqAPI(url, 'GET')
    res = res.replace(/\\/g, '')
    try {
        draft_id = res.split('"summary":true,"ad_draft_id":"')[1].split('"')[0]
    } catch (error) {

    }
    return draft_id
}


async function createCampDraft(draft_id, data) {
    let url = `https://adsmanager-graph.facebook.com/v15.0/${draft_id}/addraft_fragments?access_token=${data.token}`
    let configCamp = [
        {
            "field": "can_use_spend_cap",
            "old_value": null,
            "new_value": true
        },
        {
            "field": "name",
            "old_value": null,
            "new_value": data.name
        },
        {
            "field": "metrics_metadata",
            "old_value": null,
            "new_value": {
                "budget_optimization": [
                    "default_on"
                ]
            }
        },
        {
            "field": "campaign_group_creation_source",
            "old_value": null,
            "new_value": "click_quick_create"
        },
        {
            "field": "is_odax_campaign_group",
            "old_value": null,
            "new_value": true
        },
        {
            "field": "special_ad_categories",
            "old_value": null,
            "new_value": [
                "NONE"
            ]
        },
        {
            "field": "status",
            "old_value": null,
            "new_value": "ACTIVE"
        },
        {
            "field": "special_ad_category",
            "old_value": null,
            "new_value": "NONE"
        },
        {
            "field": "objective",
            "old_value": null,
            "new_value": "OUTCOME_SALES"
        },
        {
            "field": "buying_type",
            "old_value": null,
            "new_value": "AUCTION"
        }
    ]
    var formData = new FormData();
    formData.append('ad_object_type', 'campaign');
    formData.append('values', JSON.stringify(configCamp));
    let response = await reqAPI(url, 'POST', {}, formData)
    let json = JSON.parse(response)
    try {
        return json.ad_object_id
    } catch (error) {
        return 'error'
    }
}

function getCurrentDateTimeWithOffset() {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = String(currentDate.getMonth() + 1).padStart(2, '0');
    const day = String(currentDate.getDate()).padStart(2, '0');
    const hours = String(currentDate.getHours()).padStart(2, '0');
    const minutes = String(currentDate.getMinutes()).padStart(2, '0');
    const seconds = String(currentDate.getSeconds()).padStart(2, '0');
    const timezoneOffset = currentDate.getTimezoneOffset();
    const offsetHours = Math.floor(Math.abs(timezoneOffset) / 60).toString().padStart(2, '0');
    const offsetMinutes = (Math.abs(timezoneOffset) % 60).toString().padStart(2, '0');
    const offsetSign = timezoneOffset < 0 ? '+' : '-';

    const formattedDateTime = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}${offsetSign}${offsetHours}${offsetMinutes}`;
    return formattedDateTime;
}

async function createAdGroupDraft(draft_id, campaign_id, data) {
    let url = `https://adsmanager-graph.facebook.com/v15.0/${draft_id}/addraft_fragments?access_token=${data.token}`
    const formattedDate = getCurrentDateTimeWithOffset();

    let arr = ['CLP', 'COP', 'CRC', 'HUF', 'ISK', 'IDR', 'JPY', 'KRW', 'PYG', 'TWD', 'VND']
    if (!arr.includes(data.currency)) {
        data.budget = data.budget * 100;
    }

    var targetAuto = {
        "field": "targeting",
        "old_value": null,
        "new_value": {
            "age_max": data.max_age,
            "user_device": [],
            "excluded_publisher_list_ids": [],
            "geo_locations": {
                "countries": [
                    "US"
                ],
                "location_types": [
                    "home",
                    "recent"
                ]
            },
            "genders": (data.gender == 0) ? [] : [parseInt(data.gender)],
            "age_min": data.min_age,
            "excluded_brand_safety_content_types": [],
            "excluded_user_device": [],
            "wireless_carrier": [],
            "user_os": [],
            "excluded_geo_locations": {
                "regions": [
                    {
                        "key": "3844",
                        "name": "Alaska",
                        "country": "US"
                    },
                    {
                        "key": "3854",
                        "name": "Hawaii",
                        "country": "US"
                    }
                ]
            },
            "brand_safety_content_filter_levels": [
                "FACEBOOK_STANDARD",
                "AN_STANDARD"
            ]
        }
    }
    var placement = {
        "field": "placement",
        "new_value": {
            "user_device": [],
            "excluded_publisher_list_ids": [],
            "facebook_positions": [
                "feed",
                "facebook_reels",
                "video_feeds"
            ],
            "excluded_brand_safety_content_types": [],
            "oculus_positions": [],
            "excluded_user_device": [],
            "wireless_carrier": [],
            "device_platforms": [
                "mobile",
                "desktop"
            ],
            "user_os": [],
            "brand_safety_content_filter_levels": [],
            "publisher_platforms": [
                "facebook"
            ]
        }
    }

    var targetFb = {
        "field": "targeting",
        "old_value": null,
        "new_value": {
            "age_max": data.max_age,
            "user_device": [],
            "excluded_publisher_list_ids": [],
            "geo_locations": {
                "countries": [
                    "US"
                ],
                "location_types": [
                    "home",
                    "recent"
                ]
            },
            "facebook_positions": [
                "feed",
                "facebook_reels",
                "video_feeds"
            ],
            "genders": (data.gender == 0) ? [] : [parseInt(data.gender)],
            "age_min": data.min_age,
            "excluded_brand_safety_content_types": [],
            "oculus_positions": [],
            "excluded_user_device": [],
            "wireless_carrier": [],
            "device_platforms": [
                "mobile",
                "desktop"
            ],
            "user_os": [],
            "excluded_geo_locations": {
                "regions": [
                    {
                        "key": "3844",
                        "name": "Alaska",
                        "country": "US"
                    },
                    {
                        "key": "3854",
                        "name": "Hawaii",
                        "country": "US"
                    }
                ]
            },
            "brand_safety_content_filter_levels": [],
            "publisher_platforms": [
                "facebook"
            ]
        }
    }

    var configAdSet = [
        {
            "field": "optimization_goal",
            "old_value": null,
            "new_value": "OFFSITE_CONVERSIONS"
        },
        {
            "field": "targeting_as_signal",
            "new_value": 3
        },
        {
            "field": "parentAdObjectID",
            "old_value": null,
            "new_value": campaign_id
        },
        {
            "field": "pacing_type",
            "new_value": [
                "standard"
            ]
        },
        {
            "field": "start_time",
            "old_value": null,
            "new_value": formattedDate
        },
        {
            "field": "campaign_id",
            "old_value": null,
            "new_value": campaign_id
        },
        {
            "field": "daily_budget",
            "new_value": data.budget
        },
        {
            "field": "name",
            "old_value": null,
            "new_value": `${data.name}.`
        },
        {
            "field": "campaign_creation_source",
            "old_value": null,
            "new_value": "click_quick_create"
        },
        {
            "field": "status",
            "old_value": null,
            "new_value": "ACTIVE"
        },
        {
            "field": "bid_strategy",
            "new_value": "LOWEST_COST_WITHOUT_CAP"
        },
        {
            "field": "billing_event",
            "old_value": null,
            "new_value": "IMPRESSIONS"
        },
        {
            "field": "is_autobid",
            "new_value": true
        },
        {
            "field": "promoted_object",
            "new_value": {
                "pixel_id": data.pixel,
                "custom_event_type": "PURCHASE"
            }
        },
        {
            "field": "lifetime_budget",
            "new_value": 0
        },
        {
            "field": "attribution_spec",
            "old_value": null,
            "new_value": [
                {
                    "event_type": "CLICK_THROUGH",
                    "window_days": 7
                },
                {
                    "event_type": "VIEW_THROUGH",
                    "window_days": 1
                }
            ]
        },
        {
            "field": "is_average_price_pacing",
            "new_value": false
        }
    ]
    if (data.posistion) {
        configAdSet.push(targetAuto)
    } else {
        configAdSet.push(targetFb)
        configAdSet.push(placement)
    }
    var formData = new FormData();
    formData.append('ad_object_type', 'ad_set');
    formData.append('parent_ad_object_id', campaign_id);
    formData.append('values', JSON.stringify(configAdSet));
    let response = await reqAPI(url, 'POST', {}, formData)
    let json = JSON.parse(response)
    try {
        return json.ad_object_id
    } catch (error) {
        return 'error'
    }
}

async function createAdsDraft(draft_id, campaign_id, adset_id, data) {
    let url = `https://adsmanager-graph.facebook.com/v15.0/${draft_id}/addraft_fragments?access_token=${data.token}`
    let cofigAds = [
        {
            "field": "parentAdObjectID",
            "old_value": null,
            "new_value": adset_id
        },
        {
            "field": "campaign_id",
            "old_value": null,
            "new_value": campaign_id
        },
        {
            "field": "meta_reward_adgroup_status",
            "new_value": "INACTIVE"
        },
        {
            "field": "name",
            "old_value": null,
            "new_value": `${data.name}..`
        },
        {
            "field": "metadata",
            "new_value": {
                "carousel_style": "others"
            }
        },
        {
            "field": "creative",
            "old_value": null,
            "new_value": {
                "object_type": "VIDEO",
                "contextual_multi_ads": {
                    "eligibility": [
                        "POST_AD_ENGAGEMENT_FEED",
                        "POST_AD_ENGAGEMENT_SEED_AD",
                        "STANDALONE_FEED"
                    ],
                    "enroll_status": "OPT_IN"
                },
                "degrees_of_freedom_spec": {
                    "creative_features_spec": {
                        "standard_enhancements": {
                            "action_metadata": {
                                "type": "DEFAULT"
                            },
                            "enroll_status": "OPT_IN"
                        }
                    },
                    "degrees_of_freedom_type": "USER_ENROLLED_AUTOFLOW"
                },
                "object_story_id": data.post_id,
                "facebook_branded_content": {},
                "branded_content": {}
            }
        },
        {
            "field": "tracking_specs",
            "old_value": null,
            "new_value": [
                {
                    "action.type": [
                        "offsite_conversion"
                    ],
                    "fb_pixel": [
                        data.pixel
                    ]
                }
            ]
        },
        {
            "field": "status",
            "old_value": null,
            "new_value": "ACTIVE"
        },
        {
            "field": "adset_id",
            "old_value": null,
            "new_value": adset_id
        },
        {
            "field": "display_sequence",
            "old_value": null,
            "new_value": 0
        },
        {
            "field": "ad_creation_source",
            "old_value": null,
            "new_value": "click_quick_create"
        }
    ]
    var formData = new FormData();
    formData.append('ad_object_type', 'ad');
    formData.append('parent_ad_object_id', adset_id);
    formData.append('values', JSON.stringify(cofigAds));
    let response = await reqAPI(url, 'POST', {}, formData)
    let json = JSON.parse(response)
    try {
        return json.ad_object_id
    } catch (error) {
        return 'error'
    }
}

async function createAdsUploadDraft(draft_id, campaign_id, adset_id, video_id, thumb_url, data) {
    let url = `https://adsmanager-graph.facebook.com/v15.0/${draft_id}/addraft_fragments?access_token=${data.token}`
    let cofigAds = [
        {
            "field": "parentAdObjectID",
            "old_value": null,
            "new_value": adset_id
        },
        {
            "field": "campaign_id",
            "old_value": null,
            "new_value": campaign_id
        },
        {
            "field": "meta_reward_adgroup_status",
            "old_value": null,
            "new_value": "INACTIVE"
        },
        {
            "field": "name",
            "old_value": null,
            "new_value": `${data.name}..`
        },
        {
            "field": "metadata",
            "old_value": null,
            "new_value": {
                "carousel_style": "others",
                "ad_standard_enhancements_edit_source": 4
            }
        },
        {
            "field": "creative",
            "old_value": null,
            "new_value": {
                "object_type": "VIDEO",
                "object_story_spec": {
                    "page_id": data.page_id,
                    "video_data": {
                        "call_to_action": {
                            "type": "SHOP_NOW",
                            "value": {
                                "link": data.action_link
                            }
                        },
                        "video_id": video_id,
                        "image_url": thumb_url,
                        "caption_ids": null,
                        "video_thumbnail_source": "custom",
                        "message": data.content,
                        "title": data.title
                    }
                },
                "degrees_of_freedom_spec": {
                    "creative_features_spec": {
                        "standard_enhancements": {
                            "action_metadata": {
                                "type": "DEFAULT"
                            },
                            "enroll_status": "OPT_IN"
                        },
                        "advantage_plus_creative": {
                            "enroll_status": "OPT_IN"
                        }
                    },
                    "degrees_of_freedom_type": "USER_ENROLLED_AUTOFLOW"
                },
                "thumbnail_url": thumb_url,
            }
        },
        {
            "field": "tracking_specs",
            "old_value": null,
            "new_value": [
                {
                    "action.type": [
                        "offsite_conversion"
                    ],
                    "fb_pixel": [
                        data.pixel
                    ]
                }
            ]
        },
        {
            "field": "status",
            "old_value": null,
            "new_value": "ACTIVE"
        },
        {
            "field": "adset_id",
            "old_value": null,
            "new_value": adset_id
        },
        {
            "field": "display_sequence",
            "old_value": null,
            "new_value": 0
        },
        {
            "field": "ad_creation_source",
            "old_value": null,
            "new_value": "click_quick_create"
        }
    ]
    var formData = new FormData();
    formData.append('ad_object_type', 'ad');
    formData.append('parent_ad_object_id', adset_id);
    formData.append('values', JSON.stringify(cofigAds));
    let response = await reqAPI(url, 'POST', {}, formData)
    let json = JSON.parse(response)
    try {
        return json.ad_object_id
    } catch (error) {
        return 'error'
    }

}

async function createCamp(data) {
    let token = await chrome.storage.local.get(['token']); token = token.token
    var obj = {
        "name": data.name + '.',
        "objective": "OUTCOME_SALES",
        "status": "ACTIVE",
        "special_ad_categories": "[]"
    }
    var formData = new FormData();
    formData.append('access_token', token);
    Object.keys(obj).forEach(key => formData.append(key, obj[key]));

    let url = `https://graph.facebook.com/v15.0/act_${data.act_id}/campaigns`
    let response = await reqAPI(url, 'POST', {}, formData)
    var obj = JSON.parse(response);
    return obj
}

async function createAdGroup(campaign_id, data) {
    const today = new Date();
    const day = today.getDate().toString().padStart(2, "0");
    const month = (today.getMonth() + 1).toString().padStart(2, "0");
    const year = today.getFullYear();
    const formattedDate = `${day}-${month}-${year}`;
    var target = {
        "age_min": data.min_age,
        "age_max": data.max_age,
        "genders": [data.gender],
        "geo_locations": {
            "countries": [
                "US"
            ],
            "location_types": [
                "home",
                "recent"
            ]
        },
        "excluded_geo_locations": {
            "regions": [
                {
                    "key": "3844",
                    "name": "Alaska",
                    "country": "US"
                },
                {
                    "key": "3854",
                    "name": "Hawaii",
                    "country": "US"
                }
            ]
        },
    }
    if (!data.posistion) {
        target.publisher_platforms = ["facebook"]
        target.facebook_positions = ["feed", "video_feeds", "facebook_reels"]
        target.device_platforms = ["mobile", "desktop"]
    }

    let arr = ['CLP', 'COP', 'CRC', 'HUF', 'ISK', 'IDR', 'JPY', 'KRW', 'PYG', 'TWD', 'VND']
    if (!arr.includes(data.currency)) {
        data.budget = data.budget * 100;
    }

    var obj = {
        "status": "ACTIVE",
        "name": `${data.name}.`,
        "campaign_id": campaign_id,
        // "start_time": formattedDate,
        "bid_strategy": "LOWEST_COST_WITHOUT_CAP",
        "daily_budget": data.budget,
        "billing_event": "IMPRESSIONS",
        "optimization_goal": "REACH",
        "promoted_object": `{"pixel_id": ${data.pixel},"custom_event_type":"PURCHASE"}`,
        "optimization_goal": "OFFSITE_CONVERSIONS",
        "objective": "OUTCOME_SALES",
        "targeting": JSON.stringify(target),
        "brand_safety_content_filter_levels": ["FACEBOOK_STANDARD"]
    }
    var formData = new FormData();
    formData.append('access_token', data.token);
    Object.keys(obj).forEach(key => formData.append(key, obj[key]));

    let url = `https://graph.facebook.com/v15.0/act_${data.act_id}/adsets`
    let response = await reqAPI(url, 'POST', {}, formData)
    var obj = JSON.parse(response);
    return obj
}

async function createAdcreative(data) {
    var obj = {
        "name": "sMt Adcreative",
        "object_story_id": data.post_id
    }
    var formData = new FormData();
    formData.append('access_token', data.token);
    Object.keys(obj).forEach(key => formData.append(key, obj[key]));

    let url = `https://graph.facebook.com/v15.0/act_${data.act_id}/adcreatives`
    let response = await reqAPI(url, 'POST', {}, formData)
    var obj = JSON.parse(response);
    return obj
}

async function upLoadVideo(data) {
    let token = await chrome.storage.local.get(['token']); token = token.token
    var url = `https://adsmanager-graph.facebook.com/v15.0/act_${data.act_id}/advideos`
    var formData = new FormData();
    formData.append('access_token', token);
    formData.append('file_url', data.url_video);
    formData.append('name', 'sMT');
    let response = await reqAPI(url, 'POST', {}, formData)
    var obj = JSON.parse(response);
    return obj
}

async function uploadThumb(data) {
    try {
        const response = await fetch(data.url_thumb);
        const arrayBuffer = await response.arrayBuffer();
        const byteArray = new Uint8Array(arrayBuffer);
        // const base64String = btoa(String.fromCharCode.apply(null, byteArray));
        const base64String = btoa(new Uint8Array(byteArray).reduce(function (data, byte) {
            return data + String.fromCharCode(byte);
        }, ''));
        let url = `https://adsmanager-graph.facebook.com/v15.0/act_${data.act_id}/adimages?access_token=${data.token}`
        var formData = new FormData();
        formData.append('bytes', base64String);
        formData.append('name', 'sMT');
        let res = await reqAPI(url, 'POST', {}, formData)
        var obj = JSON.parse(res);
        var thumb_link = obj.images.sMT.url
        return thumb_link
    } catch (error) {
        return 'error'
    }
}

async function createAdcreativeUpload(data, video_id) {
    let token = await chrome.storage.local.get(['token']); token = token.token
    let videoData = {
        "call_to_action": {
            "value": { "link": data.action_link },
            "type": "SHOP_NOW"
        },
        "video_id": video_id,
        "title": data.title,
        "message": data.content,
        "image_url": data.url_thumb,
    }
    var obj = {
        "name": "adcreative video spec",
        "object_story_spec": `{"video_data": ${JSON.stringify(videoData)}, "page_id": ${data.page_id},}`
    }
    var formData = new FormData();
    formData.append('access_token', token);
    Object.keys(obj).forEach(key => formData.append(key, obj[key]));

    let url = `https://graph.facebook.com/v15.0/act_${data.act_id}/adcreatives`
    let response = await reqAPI(url, 'POST', {}, formData)
    var obj = JSON.parse(response);
    return obj
}


async function createAds(adset_id, adcreative_id, data) {
    var obj = {
        "name": `${data.name}..`,
        "adset_id": adset_id,
        "creative": JSON.stringify({
            "creative_id": adcreative_id
        }),
        "status": "ACTIVE"
    }
    var formData = new FormData();
    formData.append('access_token', data.token);
    Object.keys(obj).forEach(key => formData.append(key, obj[key]));

    let url = `https://graph.facebook.com/v15.0/act_${data.act_id}/ads`
    let response = await reqAPI(url, 'POST', {}, formData)
    var obj = JSON.parse(response);
    return obj
}
async function addCallActionType(post_id, data) {
    let fbdt = await chrome.storage.local.get(['fbdt']); fbdt = fbdt.fbdt
    var url = `https://business.facebook.com/ads/existing_post/call_to_action/?post_ids[0]=${post_id}&page_ids[0]=${data.page_id}&ad_account_id=${data.act_id}&source_app_id=119211728144504&call_to_action_type=${data.action}&call_to_action_link=${data.action_link}`
    var formdata = new FormData()
    formdata.append('fb_dtsg', fbdt);
    formdata.append("__a", "1")
    let response = await reqAPI(url, 'POST', {}, formdata)
    let flag = response.indexOf('success')
    if (flag > 0) {
        return response
    }
    return false
}

async function turnOffNotify(act) {
    let objTemp = await chrome.storage.local.get('fbdt')
    let fbdt = objTemp.fbdt
    let urlres = `https://business.facebook.com/ads/manager/post_all_adaccount_notifications/?ad_account_id=${act}&is_adaccount_notifications_enabled=false`
    let formdata = new FormData();
    formdata.append("__a", "1");
    formdata.append("fb_dtsg", fbdt);
    let res = await reqAPI(urlres, 'POST', {}, formdata)
}
//create_bm
async function create_ad_in_bm(bm, name, currency, timezone) {
    let token = await chrome.storage.local.get(['token']); token = token.token
    let url = `https://graph.facebook.com/v14.0/${bm}/adaccount?access_token=${token}&__cppo=1`
    var formdata = new FormData();
    formdata.append("currency", currency);
    formdata.append("end_advertiser", bm);
    formdata.append("media_agency", "UNFOUND");
    formdata.append("name", name);
    formdata.append("partner", "UNFOUND");
    formdata.append("timezone_id", timezone);
    let response = await reqAPI(url, 'POST', {}, formdata)
    var obj = JSON.parse(response);
    var result = ''
    if ('id' in obj) {
        result = 'Tạo thành công ' + obj.id
    }
    if ('error' in obj) {
        result = 'Sảy ra lỗi| ' + obj.error.message
    }
    return result
}

function getStatusAcc(num) {
    let astatus = ''
    switch (num) {
        case 1:
            astatus = 'Live';
            break;
        case 2:
            astatus = 'Die';
            break;
        case 3:
            astatus = 'Nợ';
            break;
        case 7:
            astatus = "Review";
            break;
        case 8:
            astatus = "Settlement";
            break;
        case 9:
            astatus = "Ân hạn";
            break;
        case 100:
            astatus = 'Closure';
            break;
        case 101:
            astatus = 'Đóng';
            break;
        case 201:
            astatus = "Any Active";
            break;
        case 202:
            astatus = "Any Close";
            break;
        default:
            astatus = "Unknow"
            break;
    }
    return astatus
}

function getStatusAccRender(num) {
    let astatus = ''
    switch (num) {
        case 'Live':
            astatus = '<i class="fa-solid fa-circle fa-xs" style="color: #03b800;"></i>'
            break;
        case 'Die':
            astatus = '<i class="fa-solid fa-circle fa-xs" style="color: #ff0000;"></i>'
            break;
        case 'Nợ':
            astatus = '<i class="fa-solid fa-circle fa-xs" style="color: #ffa500;"></i>'
            break;
        case 'Review':
            astatus = '<i class="fa-solid fa-circle fa-xs" style="color: #ffa500;"></i>'
            break;
        case 'Settlement':
            astatus = '<i class="fa-solid fa-circle fa-xs" style="color: #ffa500;"></i>'
            break;
        case 'Ân hạn':
            astatus = '<i class="fa-solid fa-circle fa-xs" style="color: #bc00f0;"></i>'

            break;
        case 'Closure':
            astatus = '<i class="fa-solid fa-circle fa-xs" style="color: #ffa500;"></i>'

            break;
        case 'Đóng':
            astatus = '<i class="fa-solid fa-circle fa-xs" style="color: #504e4e;"></i>'
            break;
        case 'Any Active':
            astatus = '<i class="fa-solid fa-circle fa-xs" style="color: #00abd6;"></i>'

            break;
        case 'Any Close':
            astatus = '<i class="fa-solid fa-circle fa-xs" style="color: #00abd6;"></i>'
            break;
        default:
            astatus = '<i class="fa-solid fa-circle fa-xs" style="color: #00abd6;"></i>'
            break;
    }
    return astatus
}

function coverCurrency(num, currency) {
    num = +num;
    if (currency == 'round') {
        return Math.round((num + Number.EPSILON) * 10) / 10
    }
    let arr = ['CLP', 'COP', 'CRC', 'HUF', 'ISK', 'IDR', 'JPY', 'KRW', 'PYG', 'TWD', 'VND']
    let currencies = 100
    if (arr.includes(currency)) {
        currencies = 1
    }
    return Math.round(((num / currencies) + Number.EPSILON) * 10) / 10
}

function mony(number) {
    return number.toLocaleString('vi-VN', { style: 'decimal', decimalSeparator: '.', groupingSeparator: ',' })
}

async function removeAdminAD(id, user_id) {
    let token = await chrome.storage.local.get('token');
    token = token.token
    var formdata = new FormData();
    formdata.append("method", "delete");
    let url = `https://graph.facebook.com/v15.0/act_${id}/users?uid=${user_id}&access_token=${token}`
    let res = await reqAPI(url, 'POST', {}, formdata)
    let obj = JSON.parse(res)
    return obj
}


async function removeAdminBM(id) {
    let token = await chrome.storage.local.get('token');
    token = token.token
    var formdata = new FormData();
    formdata.append("method", "delete");
    let url = `https://graph.facebook.com/v15.0/${id}?access_token=${token}`
    let res = await reqAPI(url, 'POST', {}, formdata)
    let obj = JSON.parse(res)
    return obj
}

async function createRule(act, id) {
    const TRIGGER_RULE = ['CAMPAIGN', 'ADSET', 'AD']
    var fetches = []
    for (var trig of TRIGGER_RULE) {
        var objRule = {
            "name": "sMT",
            "evaluation_spec": JSON.stringify({
                "evaluation_type": "SCHEDULE",
                "filters": [
                    {
                        "field": 'campaign.id',
                        "operator": "IN",
                        "value": [id]
                    },
                    {
                        "field": "entity_type",
                        "operator": "EQUAL",
                        "value": trig,
                    },
                    {
                        "field": "time_preset",
                        "value": "MAXIMUM",
                        "operator": "EQUAL"
                    }
                ]
            }),
            "execution_spec": JSON.stringify({
                "execution_type": "UNPAUSE"
            }),
            "schedule_spec": JSON.stringify({
                "schedule_type": "DAILY"
            })
        }
        var formData = new FormData();
        Object.keys(objRule).forEach(key => formData.append(key, objRule[key]));
        fetches.push(pushRule(act, trig, formData))
    }
    var arrs = await Promise.all(fetches).then(function (text) {
        return text
    })
    return ` Tạo rule Bật ${arrs.join(' | ')}`
}

async function createRuleBudget(act, id, budgetUp, budgetMax) {
    var objRule = {
        "name": "sMT_Bud",
        "evaluation_spec": JSON.stringify({
            "evaluation_type": "SCHEDULE",
            "filters": [
                {
                    "field": "campaign.id",
                    "operator": "IN",
                    "value": [
                        id
                    ]
                },
                {
                    "field": "adset.budget_reset_period",
                    "operator": "IN",
                    "value": [
                        "DAY"
                    ]
                },
                {
                    "field": "entity_type",
                    "value": "ADSET",
                    "operator": "EQUAL"
                },
                {
                    "field": "time_preset",
                    "value": "MAXIMUM",
                    "operator": "EQUAL"
                }
            ]
        }),
        "execution_spec": JSON.stringify({
            "execution_type": "CHANGE_BUDGET",
            "execution_options": [
                {
                    "field": "action_frequency",
                    "value": 1440,
                    "operator": "EQUAL"
                },
                {
                    "field": "change_spec",
                    "value": {
                        "amount": budgetUp,
                        "limit": budgetMax,
                        "unit": "PERCENTAGE"
                    },
                    "operator": "EQUAL"
                }
            ]
        }),
        "schedule_spec": JSON.stringify({
            "schedule_type": "DAILY"
        })
    }
    var formData = new FormData();
    Object.keys(objRule).forEach(key => formData.append(key, objRule[key]));
    let result = await pushRule(act, 'ADSET', formData)
    return ` Tạo rule ngân sách ${result}`
}


async function pushRule(act, trig, formData) {
    var resText = ''
    var objTemp = await chrome.storage.local.get('token');
    var token = objTemp.token;
    let url = `https://graph.facebook.com/v16.0/act_${act}/adrules_library?access_token=${token}`

    let res = await reqAPI(url, 'POST', {}, formData)
    let json = JSON.parse(res)
    if ('error' in json) {
        resText = `${trig}: ${json.error.message}`
    } else {
        resText = `${trig}: Done`
    }
    return resText
}

objTimeZone = {
    0: 'Unknow',
    1: 'America_Los_Angeles',
    2: 'America_Denver',
    3: 'Pacific_Honolulu',
    4: 'America_Anchorage',
    5: 'America_Phoenix',
    6: 'America_Chicago',
    7: 'America_New_York',
    8: 'Asia_Dubai',
    9: 'America_Argentina_San_Luis',
    10: 'America_Argentina_Buenos_Aires',
    11: 'America_Argentina_Salta',
    12: 'Europe_Vienna',
    13: 'Australia_Perth',
    14: 'Australia_Broken_Hill',
    15: 'Australia_Sydney',
    16: 'Europe_Sarajevo',
    17: 'Asia_Dhaka',
    18: 'Europe_Brussels',
    19: 'Europe_Sofia',
    20: 'Asia_Bahrain',
    21: 'America_La_Paz',
    22: 'America_Noronha',
    23: 'America_Campo_Grande',
    24: 'America_Belem',
    25: 'America_Sao_Paulo',
    26: 'America_Nassau',
    27: 'America_Dawson',
    28: 'America_Vancouver',
    29: 'America_Dawson_Creek',
    30: 'America_Edmonton',
    31: 'America_Rainy_River',
    32: 'America_Regina',
    33: 'America_Atikokan',
    34: 'America_Iqaluit',
    35: 'America_Toronto',
    36: 'America_Blanc_Sablon',
    37: 'America_Halifax',
    38: 'America_St_Johns',
    39: 'Europe_Zurich',
    40: 'Pacific_Easter',
    41: 'America_Santiago',
    42: 'Asia_Shanghai',
    43: 'America_Bogota',
    44: 'America_Costa_Rica',
    45: 'Asia_Nicosia',
    46: 'Europe_Prague',
    47: 'Europe_Berlin',
    48: 'Europe_Copenhagen',
    49: 'America_Santo_Domingo',
    50: 'Pacific_Galapagos',
    51: 'America_Guayaquil',
    52: 'Europe_Tallinn',
    53: 'Africa_Cairo',
    54: 'Atlantic_Canary',
    55: 'Europe_Madrid',
    56: 'Europe_Helsinki',
    57: 'Europe_Paris',
    58: 'Europe_London',
    59: 'Africa_Accra',
    60: 'Europe_Athens',
    61: 'America_Guatemala',
    62: 'Asia_Hong_Kong',
    63: 'America_Tegucigalpa',
    64: 'Europe_Zagreb',
    65: 'Europe_Budapest',
    66: 'Asia_Jakarta',
    67: 'Asia_Makassar',
    68: 'Asia_Jayapura',
    69: 'Europe_Dublin',
    70: 'Asia_Jerusalem',
    71: 'Asia_Kolkata',
    72: 'Asia_Baghdad',
    73: 'Atlantic_Reykjavik',
    74: 'Europe_Rome',
    75: 'America_Jamaica',
    76: 'Asia_Amman',
    77: 'Asia_Tokyo',
    78: 'Africa_Nairobi',
    79: 'Asia_Seoul',
    80: 'Asia_Kuwait',
    81: 'Asia_Beirut',
    82: 'Asia_Colombo',
    83: 'Europe_Vilnius',
    84: 'Europe_Luxembourg',
    85: 'Europe_Riga',
    86: 'Africa_Casablanca',
    87: 'Europe_Skopje',
    88: 'Europe_Malta',
    89: 'Indian_Mauritius',
    90: 'Indian_Maldives',
    91: 'America_Tijuana',
    92: 'America_Hermosillo',
    93: 'America_Mazatlan',
    94: 'America_Mexico_City',
    95: 'Asia_Kuala_Lumpur',
    96: 'Africa_Lagos',
    97: 'America_Managua',
    98: 'Europe_Amsterdam',
    99: 'Europe_Oslo',
    100: 'Pacific_Auckland',
    101: 'Asia_Muscat',
    102: 'America_Panama',
    103: 'America_Lima',
    104: 'Asia_Manila',
    105: 'Asia_Karachi',
    106: 'Europe_Warsaw',
    107: 'America_Puerto_Rico',
    108: 'Asia_Gaza',
    109: 'Atlantic_Azores',
    110: 'Europe_Lisbon',
    111: 'America_Asuncion',
    112: 'Asia_Qatar',
    113: 'Europe_Bucharest',
    114: 'Europe_Belgrade',
    115: 'Europe_Kaliningrad',
    116: 'Europe_Moscow',
    117: 'Europe_Samara',
    118: 'Asia_Yekaterinburg',
    119: 'Asia_Omsk',
    120: 'Asia_Krasnoyarsk',
    121: 'Asia_Irkutsk',
    122: 'Asia_Yakutsk',
    123: 'Asia_Vladivostok',
    124: 'Asia_Magadan',
    125: 'Asia_Kamchatka',
    126: 'Asia_Riyadh',
    127: 'Europe_Stockholm',
    128: 'Asia_Singapore',
    129: 'Europe_Ljubljana',
    130: 'Europe_Bratislava',
    131: 'America_El_Salvador',
    132: 'Asia_Bangkok',
    133: 'Africa_Tunis',
    134: 'Europe_Istanbul',
    135: 'America_Port_Of_Spain',
    136: 'Asia_Taipei',
    137: 'Europe_Kiev',
    138: 'America_Montevideo',
    139: 'America_Caracas',
    140: 'Asia_Ho_Chi_Minh',
    141: 'Africa_Johannesburg',
    142: 'America_Winnipeg',
    143: 'America_Detroit',
    144: 'Australia_Melbourne',
    145: 'Asia_Kathmandu',
    146: 'Asia_Baku',
    147: 'Africa_Abidjan',
    148: 'Africa_Addis_Ababa',
    149: 'Africa_Algiers',
    150: 'Africa_Asmara',
    151: 'Africa_Bamako',
    152: 'Africa_Bangui',
    153: 'Africa_Banjul',
    154: 'Africa_Bissau',
    155: 'Africa_Blantyre',
    156: 'Africa_Brazzaville',
    157: 'Africa_Bujumbura',
    158: 'Africa_Ceuta',
    159: 'Africa_Conakry',
    160: 'Africa_Dakar',
    161: 'Africa_Dar_Es_Salaam',
    162: 'Africa_Djibouti',
    163: 'Africa_Douala',
    164: 'Africa_El_Aaiun',
    165: 'Africa_Freetown',
    166: 'Africa_Gaborone',
    167: 'Africa_Harare',
    168: 'Africa_Juba',
    169: 'Africa_Kampala',
    170: 'Africa_Khartoum',
    171: 'Africa_Kigali',
    172: 'Africa_Kinshasa',
    173: 'Africa_Libreville',
    174: 'Africa_Lome',
    175: 'Africa_Luanda',
    176: 'Africa_Lubumbashi',
    177: 'Africa_Lusaka',
    178: 'Africa_Malabo',
    179: 'Africa_Maputo',
    180: 'Africa_Maseru',
    181: 'Africa_Mbabane',
    182: 'Africa_Mogadishu',
    183: 'Africa_Monrovia',
    184: 'Africa_Ndjamena',
    185: 'Africa_Niamey',
    186: 'Africa_Nouakchott',
    187: 'Africa_Ouagadougou',
    188: 'Africa_Porto_Novo',
    189: 'Africa_Sao_Tome',
    190: 'Africa_Tripoli',
    191: 'Africa_Windhoek',
    192: 'America_Adak',
    193: 'America_Anguilla',
    194: 'America_Antigua',
    195: 'America_Araguaina',
    196: 'America_Argentina_Catamarca',
    197: 'America_Argentina_Cordoba',
    198: 'America_Argentina_Jujuy',
    199: 'America_Argentina_La_Rioja',
    200: 'America_Argentina_Mendoza',
    201: 'America_Argentina_Rio_Gallegos',
    202: 'America_Argentina_San_Juan',
    203: 'America_Argentina_Tucuman',
    204: 'America_Argentina_Ushuaia',
    205: 'America_Aruba',
    206: 'America_Bahia',
    207: 'America_Bahia_Banderas',
    208: 'America_Barbados',
    209: 'America_Belize',
    210: 'America_Boa_Vista',
    211: 'America_Boise',
    212: 'America_Cambridge_Bay',
    213: 'America_Cancun',
    214: 'America_Cayenne',
    215: 'America_Cayman',
    216: 'America_Chihuahua',
    217: 'America_Creston',
    218: 'America_Cuiaba',
    219: 'America_Curacao',
    220: 'America_Danmarkshavn',
    221: 'America_Dominica',
    222: 'America_Eirunepe',
    223: 'America_Fort_Nelson',
    224: 'America_Fortaleza',
    225: 'America_Glace_Bay',
    226: 'America_Godthab',
    227: 'America_Goose_Bay',
    228: 'America_Grand_Turk',
    229: 'America_Grenada',
    230: 'America_Guadeloupe',
    231: 'America_Guyana',
    232: 'America_Havana',
    233: 'America_Indiana_Indianapolis',
    234: 'America_Indiana_Knox',
    235: 'America_Indiana_Marengo',
    236: 'America_Indiana_Petersburg',
    237: 'America_Indiana_Tell_City',
    238: 'America_Indiana_Vevay',
    239: 'America_Indiana_Vincennes',
    240: 'America_Indiana_Winamac',
    241: 'America_Indianapolis',
    242: 'America_Inuvik',
    243: 'America_Juneau',
    244: 'America_Kentucky_Louisville',
    245: 'America_Kentucky_Monticello',
    246: 'America_Kralendijk',
    247: 'America_Lower_Princes',
    248: 'America_Maceio',
    249: 'America_Manaus',
    250: 'America_Marigot',
    251: 'America_Martinique',
    252: 'America_Matamoros',
    253: 'America_Menominee',
    254: 'America_Merida',
    255: 'America_Metlakatla',
    256: 'America_Miquelon',
    257: 'America_Moncton',
    258: 'America_Monterrey',
    259: 'America_Montreal',
    260: 'America_Montserrat',
    261: 'America_Nipigon',
    262: 'America_Nome',
    263: 'America_North_Dakota_Beulah',
    264: 'America_North_Dakota_Center',
    265: 'America_North_Dakota_New_Salem',
    266: 'America_Ojinaga',
    267: 'America_Pangnirtung',
    268: 'America_Paramaribo',
    269: 'America_Port_Au_Prince',
    270: 'America_Porto_Velho',
    271: 'America_Punta_Arenas',
    272: 'America_Rankin_Inlet',
    273: 'America_Recife',
    274: 'America_Resolute',
    275: 'America_Rio_Branco',
    276: 'America_Santarem',
    277: 'America_Scoresbysund',
    278: 'America_Sitka',
    279: 'America_St_Barthelemy',
    280: 'America_St_Kitts',
    281: 'America_St_Lucia',
    282: 'America_St_Thomas',
    283: 'America_St_Vincent',
    284: 'America_Swift_Current',
    285: 'America_Thule',
    286: 'America_Thunder_Bay',
    287: 'America_Tortola',
    288: 'America_Whitehorse',
    289: 'America_Yakutat',
    290: 'America_Yellowknife',
    291: 'Antarctica_Casey',
    292: 'Antarctica_Davis',
    293: 'Antarctica_Dumontdurville',
    294: 'Antarctica_Macquarie',
    295: 'Antarctica_Mawson',
    296: 'Antarctica_Mcmurdo',
    297: 'Antarctica_Palmer',
    298: 'Antarctica_Rothera',
    299: 'Antarctica_Syowa',
    300: 'Antarctica_Troll',
    301: 'Antarctica_Vostok',
    302: 'Arctic_Longyearbyen',
    303: 'Asia_Aden',
    304: 'Asia_Almaty',
    305: 'Asia_Anadyr',
    306: 'Asia_Aqtau',
    307: 'Asia_Aqtobe',
    308: 'Asia_Ashgabat',
    309: 'Asia_Atyrau',
    310: 'Asia_Barnaul',
    311: 'Asia_Bishkek',
    312: 'Asia_Brunei',
    313: 'Asia_Chita',
    314: 'Asia_Choibalsan',
    315: 'Asia_Damascus',
    316: 'Asia_Dili',
    317: 'Asia_Dushanbe',
    318: 'Asia_Famagusta',
    319: 'Asia_Hebron',
    320: 'Asia_Hovd',
    321: 'Asia_Istanbul',
    322: 'Asia_Kabul',
    323: 'Asia_Khandyga',
    324: 'Asia_Kuching',
    325: 'Asia_Macau',
    326: 'Asia_Novokuznetsk',
    327: 'Asia_Novosibirsk',
    328: 'Asia_Oral',
    329: 'Asia_Phnom_Penh',
    330: 'Asia_Pontianak',
    331: 'Asia_Pyongyang',
    332: 'Asia_Qostanay',
    333: 'Asia_Qyzylorda',
    334: 'Asia_Sakhalin',
    335: 'Asia_Samarkand',
    336: 'Asia_Srednekolymsk',
    337: 'Asia_Tashkent',
    338: 'Asia_Tbilisi',
    339: 'Asia_Tehran',
    340: 'Asia_Thimphu',
    341: 'Asia_Tomsk',
    342: 'Asia_Ulaanbaatar',
    343: 'Asia_Urumqi',
    344: 'Asia_Ust_Nera',
    345: 'Asia_Vientiane',
    346: 'Asia_Yangon',
    347: 'Asia_Yerevan',
    348: 'Atlantic_Bermuda',
    349: 'Atlantic_Cape_Verde',
    350: 'Atlantic_Faroe',
    351: 'Atlantic_Madeira',
    352: 'Atlantic_South_Georgia',
    353: 'Atlantic_St_Helena',
    354: 'Atlantic_Stanley',
    355: 'Australia_Adelaide',
    356: 'Australia_Brisbane',
    357: 'Australia_Currie',
    358: 'Australia_Darwin',
    359: 'Australia_Eucla',
    360: 'Australia_Hobart',
    361: 'Australia_Lindeman',
    362: 'Australia_Lord_Howe',
    363: 'Cet',
    364: 'Cst6Cdt',
    365: 'Eet',
    366: 'Est',
    367: 'Est5Edt',
    368: 'Etc_Gmt',
    369: 'Etc_Gmt_Plus_0',
    370: 'Etc_Gmt_Plus_1',
    371: 'Etc_Gmt_Plus_10',
    372: 'Etc_Gmt_Plus_11',
    373: 'Etc_Gmt_Plus_12',
    374: 'Etc_Gmt_Plus_2',
    375: 'Etc_Gmt_Plus_3',
    376: 'Etc_Gmt_Plus_4',
    377: 'Etc_Gmt_Plus_5',
    378: 'Etc_Gmt_Plus_6',
    379: 'Etc_Gmt_Plus_7',
    380: 'Etc_Gmt_Plus_8',
    381: 'Etc_Gmt_Plus_9',
    382: 'Etc_Gmt_Minus_0',
    383: 'Etc_Gmt_Minus_1',
    384: 'Etc_Gmt_Minus_10',
    385: 'Etc_Gmt_Minus_11',
    386: 'Etc_Gmt_Minus_12',
    387: 'Etc_Gmt_Minus_13',
    388: 'Etc_Gmt_Minus_14',
    389: 'Etc_Gmt_Minus_2',
    390: 'Etc_Gmt_Minus_3',
    391: 'Etc_Gmt_Minus_4',
    392: 'Etc_Gmt_Minus_5',
    393: 'Etc_Gmt_Minus_6',
    394: 'Etc_Gmt_Minus_7',
    395: 'Etc_Gmt_Minus_8',
    396: 'Etc_Gmt_Minus_9',
    397: 'Etc_Gmt0',
    398: 'Etc_Greenwich',
    399: 'Etc_Universal',
    400: 'Etc_Zulu',
    401: 'Europe_Andorra',
    402: 'Europe_Astrakhan',
    403: 'Europe_Busingen',
    404: 'Europe_Chisinau',
    405: 'Europe_Gibraltar',
    406: 'Europe_Guernsey',
    407: 'Europe_Isle_Of_Man',
    408: 'Europe_Jersey',
    409: 'Europe_Kirov',
    410: 'Europe_Mariehamn',
    411: 'Europe_Minsk',
    412: 'Europe_Monaco',
    413: 'Europe_Nicosia',
    414: 'Europe_Podgorica',
    415: 'Europe_San_Marino',
    416: 'Europe_Saratov',
    417: 'Europe_Simferopol',
    418: 'Europe_Tirane',
    419: 'Europe_Ulyanovsk',
    420: 'Europe_Uzhgorod',
    421: 'Europe_Vaduz',
    422: 'Europe_Vatican',
    423: 'Europe_Volgograd',
    424: 'Europe_Zaporozhye',
    425: 'Gmt',
    426: 'Hst',
    427: 'Indian_Antananarivo',
    428: 'Indian_Chagos',
    429: 'Indian_Christmas',
    430: 'Indian_Cocos',
    431: 'Indian_Comoro',
    432: 'Indian_Kerguelen',
    433: 'Indian_Mahe',
    434: 'Indian_Mayotte',
    435: 'Indian_Reunion',
    436: 'Met',
    437: 'Mst',
    438: 'Mst7Mdt',
    439: 'Pst8Pdt',
    440: 'Pacific_Apia',
    441: 'Pacific_Bougainville',
    442: 'Pacific_Chatham',
    443: 'Pacific_Chuuk',
    444: 'Pacific_Efate',
    445: 'Pacific_Enderbury',
    446: 'Pacific_Fakaofo',
    447: 'Pacific_Fiji',
    448: 'Pacific_Funafuti',
    449: 'Pacific_Gambier',
    450: 'Pacific_Guadalcanal',
    451: 'Pacific_Guam',
    452: 'Pacific_Kiritimati',
    453: 'Pacific_Kosrae',
    454: 'Pacific_Kwajalein',
    455: 'Pacific_Majuro',
    456: 'Pacific_Marquesas',
    457: 'Pacific_Midway',
    458: 'Pacific_Nauru',
    459: 'Pacific_Niue',
    460: 'Pacific_Norfolk',
    461: 'Pacific_Noumea',
    462: 'Pacific_Pago_Pago',
    463: 'Pacific_Palau',
    464: 'Pacific_Pitcairn',
    465: 'Pacific_Pohnpei',
    466: 'Pacific_Port_Moresby',
    467: 'Pacific_Rarotonga',
    468: 'Pacific_Saipan',
    469: 'Pacific_Tahiti',
    470: 'Pacific_Tarawa',
    471: 'Pacific_Tongatapu',
    472: 'Pacific_Wake',
    473: 'Pacific_Wallis',
    474: 'Utc',
    475: 'Wet',
    476: 'Asia_Calcutta',
    477: 'Asia_Katmandu',
    478: 'America_Nuuk',
    479: 'Num_Timezones',
}