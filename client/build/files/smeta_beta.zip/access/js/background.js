async function reqAPI(url, method, header, body) {
  var formData = new FormData();
  if (body) {
    Object.keys(body).forEach((key) => formData.append(key, body[key]));
  }
  try {
    let response = await fetch(url, {
      method: method,
      body: body ? formData : null,
      headers: header,
    });
    let html = await response.text().then((res) => res);
    return html;
  } catch (error) {
    return '{"error": {"message": "Faild to fetch reqAPI"}}';
  }
}

chrome.runtime.onMessageExternal.addListener(async (request,
  sender,
  sendResponse) => {
  if (request.url) {
    var res = await reqAPI(request.url, request.method, request.header, request.body);
    sendResponse(res);
  } else {
    sendResponse('{ "success": "true" }');
  }

  if (request.message) {
    sendResponse('{ "success": "true" }');
    return
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1],
    addRules: [{
      "id": 1,
      "priority": 1,
      "action": {
        "type": "modifyHeaders",
        "requestHeaders": [{ "header": "origin", "operation": "set", "value": "https://business.facebook.com" }]
      },
      "condition": {
        "urlFilter": "https://business.facebook.com",
        "resourceTypes": ["main_frame", "xmlhttprequest"]
      }
    }],
  });
});

chrome.tabs.onUpdated.addListener(
  function (tabId, changeInfo) {
    if (changeInfo.url) {
      if (changeInfo.url.includes('billing_hub/payment_settings') || changeInfo.url.includes('billing_hub/accounts/details')) {
        try {
          chrome.tabs.sendMessage(tabId, {
            message: 'message',
            url: changeInfo.url
          })
        } catch (error) {

        }
      }
    }
  }
);
