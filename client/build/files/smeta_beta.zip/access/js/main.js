const HOST = 'https://smeta.vn'
$(window).on('load', async function (event) {
   var smeta = await init()
   if (smeta.token == 'ERR') {
      var load = document.getElementById('loadspan');
      load.innerHTML = `<i class="fa-solid fa-triangle-exclamation" style="color:yellow"></i>Đã sảy ra lỗi với phiên đăng nhập này, hãy kiểm tra lại!`
      return
   }
   if (smeta.token == 'NO') {
      var load = document.getElementById('loadspan');
      load.innerHTML = `<i class="fa-solid fa-triangle-exclamation" style="color:yellow"></i> Chương trình này chỉ chạy khi bạn đã đăng nhập facebook!`
      return
   }

   $('.load').delay(0).fadeOut('fast');

   if (smeta.fcase == 'render') {
      let objAds = await chrome.storage.local.get(['objAds'])
      let objBM = await chrome.storage.local.get(['objBM']);
      let objFan = await chrome.storage.local.get(['objFan']);
      let objCamp = await chrome.storage.local.get(['objCamp']);
      try {
         objAds = JSON.parse(objAds.objAds)
         objBM = JSON.parse(objBM.objBM)
         objFan = JSON.parse(objFan.objFan)
         objCamp = JSON.parse(objCamp.objCamp)
      } catch (ex) {
         reload(smeta.token, smeta.fbdt)
      }
      renderHTML(smeta.token, smeta.fbdt, objAds, objBM, objFan, objCamp)
   } else {
      reload(smeta.token, smeta.fbdt)
   }
   var auth = await smetaAuth()
   if (auth) {
      renderUser(auth)
   }
   renderCuser()
   renderVersion()
   handlerEventTable()
})


async function init() {
   $('.loaddata1').show()
   $('.loaddata2').show()
   $('.loaddata3').show()
   $('.loaddata4').show()
   let token = await chrome.storage.local.get(['token']); token = token.token
   let fcase = ''
   if (token == null) {
      objToken = await getToken()
      token = objToken.token
      fbdt = objToken.fbdt
      if (token == 'ERR') {
         return { token: token }
      }
      if (token == 'NO') {
         return { token: token }
      }
      fcase = 'reload'
      chrome.storage.local.set({ 'fbdt': fbdt });
      chrome.storage.local.set({ 'token': token });
      let url = 'https://graph.facebook.com/v15.0/me?access_token=' + token;
      let json = await reqAPI(url, 'GET')
      let obj = JSON.parse(json);
      if ('name' in obj) {
         chrome.storage.local.set({ 'user_id': obj.id });
         chrome.storage.local.set({ 'user_name': obj.name });
      }
      return { token: token, fcase: fcase, fbdt: fbdt }
   } else {
      let url = 'https://graph.facebook.com/v15.0/me?access_token=' + token;
      let json = await reqAPI(url, 'GET')
      let obj = JSON.parse(json);
      if ('name' in obj) {
         fcase = 'render'
         fbdt = await chrome.storage.local.get(['fbdt']); fbdt = fbdt.fbdt
         chrome.storage.local.set({ 'token': token });
         chrome.storage.local.set({ 'fbdt': fbdt });
         chrome.storage.local.set({ 'user_id': obj.id });
         chrome.storage.local.set({ 'user_name': obj.name });
         return { token: token, fcase: fcase, fbdt: fbdt }
      }
      let clear = await chrome.storage.local.clear()
      objToken = await getToken()
      token = objToken.token
      fbdt = objToken.fbdt
      if (token == 'NO') {
         return false
      }
      fcase = 'reload'
      chrome.storage.local.set({ 'fbdt': fbdt });
      chrome.storage.local.set({ 'token': token });
      return { token: token, fcase: fcase, fbdt: fbdt }
   }
}

async function renderVersion() {
   var footercontent = document.getElementsByClassName('footercontent')[0]
   var notify_text = document.getElementById('notify-text-container')
   var manifestData = chrome.runtime.getManifest();
   var version = manifestData.version
   var versionol = await checkVersion()
   if (versionol.version > Number(version)) {
      notify_text.style.visibility = 'visible'
      notify_text.innerHTML = `
      <marquee class="notify-text"  behavior="scroll" direction="left" scrollamount="3">
         Đã có phiên bản cập nhật mới, vui lòng truy cập https://smeta.vn để tải xuống bản cập nhật v${versionol.version}
      </marquee>`
      footercontent.innerHTML = `
      <span class="copyright">sMeta.vn</span>
      <a title="Đã có phiên bản mới, vui lòng truy cập smeta.vn để cập nhật">
      <i class="fa-solid fa-triangle-exclamation fa-xs" style="color: #ff9500;"></i>
      </a>
      `
   } else {
      footercontent.innerHTML = `
      <span class="copyright">sMeta.vn</span>
      <a title="Đã cập nhật phiên bản mới nhất">
      <i class="fa-solid fa-circle-check fa-xs"
      style="color: #00d5ff;"></i>
      </a>
      `
   }
   var copyright = document.getElementsByClassName('copyright')[0]
   copyright.innerHTML = `sMeta.vn v${version}`
}

async function checkVersion() {
   let json = await reqAPI2(HOST + '/api/checkversion', 'GET')
   json = JSON.parse(json);
   return json
}

async function renderCuser() {
   let docUser = document.getElementsByClassName('c_user')[0]
   let tempLocal = await chrome.storage.local.get(['user_id', 'user_name', 'token'])
   let id = tempLocal.user_id
   let name = tempLocal.user_name
   let token = tempLocal.token

   docUser.innerHTML = `<i class="fa-brands fa-facebook" title="Click to copy token"></i>
   <span title="Click to copy link profile">${name}</span>`
   docUser.querySelector('i').onclick = () => {
      navigator.clipboard.writeText(token);
      alertGreen('Đã copy token EAAB', 2000)
   }
   docUser.querySelector('span').onclick = () => {
      navigator.clipboard.writeText(`https://facebook.com/${id}`);
      alertGreen('Đã copy link profile', 2000)
   }
}

function loadData(id) {
   let table = document.getElementById(id)
   table.innerHTML = `
   <div class="loaddata1">
   <img src="access/icon/loadingdata.gif" alt="">
   </div>
   `
}

async function reload(token, fbdt) {
   $('.loaddata1').show()
   $('.loaddata2').show()
   $('.loaddata3').show()
   $('.loaddata4').show()
   var user_id = await chrome.storage.local.get('user_id')
   user_id = user_id.user_id
   var tbAds = document.getElementById('tb')
   var tbBM = document.getElementById('tbBM')
   var selectBM = document.getElementById('listBM');
   var tbFanPage = document.getElementById('tbFanPage')
   var tbCamp = document.getElementById('tbCamp')

   tbAds.innerHTML = ''
   tbBM.innerHTML = ''
   tbFanPage.innerHTML = ''
   tbCamp.innerHTML = ''
   selectBM.innerHTML = ''

   chrome.storage.local.remove('objAds');
   chrome.storage.local.remove('objBM');
   chrome.storage.local.remove('objFan');
   chrome.storage.local.remove('objCamp');
   chrome.storage.local.remove('objPayment');
   await Promise.all([getListAccounts(token, user_id), getListBM(token, fbdt), getStatusFanPage(token, user_id)])
   getListCampaign()
   handlerEventTable()
}

function renderHTML(token, fbdt, objAds, objBM, objFan, objCamp) {
   try {
      renderHtmlAcc(objAds)
      renderHtmlBM(objBM)
      renderHtmlFan(objFan)
      renderHtmlCamp(objCamp)
   }
   catch (err) {
      reload(token, fbdt)
   }
}

document.getElementById('btnreload').addEventListener('click', async function () {
   var btn = document.getElementById('btnreload')
   btn.style.pointerEvents = 'none'
   btn.style.opacity = '0.4'

   var smeta = await init()
   if (!smeta) {
      var load = document.getElementById('loadspan');
      load.innerHTML = `[LỖI] Chương trình này chỉ chạy khi bạn đã đăng nhập facebook!`
      return
   }
   $('.load').delay(0).fadeOut('fast');
   await reload(smeta.token, smeta.fbdt)
   btn.style.removeProperty('pointer-events')
   btn.style.removeProperty('opacity')
})


function clearloadData(id) {
   $(id).delay(0).fadeOut('fast');
}

var tabLinks = document.querySelectorAll(".tablinks");
var tabContent = document.querySelectorAll(".tabcontent");

tabLinks.forEach(function (el) {
   el.addEventListener("click", openTabs);
});


async function openTabs(el) {
   var btn = el.currentTarget;
   var electronic = btn.dataset.electronic;
   tabContent.forEach(function (el) {
      el.classList.remove("active");
   });
   tabLinks.forEach(function (el) {
      el.classList.remove("active");
   });
   var fillter = document.getElementById('tbfilter')
   fillter.value = ''

   let Tabs = document.querySelector("#" + electronic)
   let btn_currency = document.getElementById('btn_currency')
   let btn_export = document.getElementById('btn_export')
   if (electronic == 'AccStatus') {
      btn_currency.style.display = 'block'
      btn_export.style.display = 'block'
   } else {
      btn_currency.style.display = 'none'
      btn_export.style.display = 'none'
   }
   if (electronic == 'Campaign') {
      getListCampaign()
   }
   Tabs.classList.add("active");
   let table = Tabs.querySelector('table')
   filterTable(table, '')
   btn.classList.add("active");
}

document.getElementById('listBM').addEventListener('change', function () {
   var currentBM = this.value;
   var listPixel = document.getElementById('listPixel')
   listPixel.innerHTML = `<option>Loading!!!</option>`
   renderPixel(currentBM)
});

document.getElementById('btn_export').addEventListener('click', async function (e) {
   var auth = await smetaAuth('Export Excel')
   var menu = document.getElementById('menu')
   if (!auth) { return alert('Vui lòng đăng nhập để sử dụng tính năng này', 2000) }
   var answer = window.confirm("Bạn có muốn xuất dữ liệu không?");
   menu.style.display = 'hidden'
   if (!answer) {
      return
   }

   let objPayment = await chrome.storage.local.get(['objPayment'])
   let objAds = await chrome.storage.local.get(['objAds'])
   let objBM = await chrome.storage.local.get(['objBM']);
   objPayment = objPayment.objPayment

   try {
      objAds = JSON.parse(objAds.objAds)
      objBM = JSON.parse(objBM.objBM)
   } catch {
      alert('Vui lòng thử lại sau vài giây', 3000)
      return
   }


   if (objPayment == null) {
      alertGreen('Vui lòng chờ, dữ liệu sẽ sớm được xuất', 3000)
      let fbdt = await chrome.storage.local.get(['fbdt'])
      fbdt = fbdt.fbdt
      chrome.storage.local.set({ 'objPayment': [] });
      var fetches = []
      for (var acc of objAds) {
         fetches.push(getPayment(acc.s_id, fbdt))
      }
      var arrs = await Promise.all(fetches).then(function (obj) {
         return obj
      })
      chrome.storage.local.set({ 'objPayment': arrs });
      objPayment = arrs
   }

   for (var acc of objAds) {
      for (subacc of objPayment) {
         if (acc.s_id == subacc.act) {
            acc.s_card = subacc.payments
            acc.bills = subacc.bills
            break
         }
      }
   }

   var arrAds = [['STT', 'Trạng Thái', 'Id Tk', 'Tên TK', 'Dư nợ', 'Ngưỡng', 'Limit', 'Chi tiêu', 'Admin', 'Tiền tệ', 'Loại TK', 'Role', 'Bill', 'Id BM', 'Payment', 'Time Zone',]]
   var arrBM = [['STT', 'Trạng Thái', 'Id Bm', 'Tên BM', 'BM level', 'Admin ẩn', 'Limit', 'Múi giờ', 'Ngày tạo']]

   for (var acc of objAds) {
      var arrContent = []
      for (var info in acc) {
         if (info.slice(0, 2) == 's_') {
            arrContent.push(acc[info])
         }
      }
      var bills = acc['bills']
      bills = bills.split('*')[0]
      // arrContent.splice(1, 0, acc['s_bm'])
      arrContent.splice(12, 0, bills)
      arrAds.push(arrContent)
   }

   for (var acc of objBM) {
      var arrContent = []
      for (var info in acc) {
         if (info != 'pixel') {
            arrContent.push(acc[info])
         }
      }
      arrBM.push(arrContent)
   }

   genareExcel(arrAds, objAds, arrBM)

})


function fitToColumn(arrAds) {
   return arrAds[0].map((a, i) => ({ wch: Math.max(...arrAds.map(a2 => a2[i] ? a2[i].toString().length : 0)) }));
}

function genareExcel(arrAds, objAds, arrBM) {
   var wb = XLSX.utils.book_new();
   wb.Props = {
      Title: "sMeta.vn - TKQC",
      Subject: "Xuât",
      Author: "smeta.vn",
      CreatedDate: new Date(2017, 12, 19)
   };
   wb.SheetNames.push("TKQC");
   wb.SheetNames.push("BM");
   var ws = XLSX.utils.aoa_to_sheet(arrAds);
   ws['!cols'] = fitToColumn(arrAds);
   var stt = 2
   for (var acc of objAds) {
      for (var info in acc) {
         if (info == 'bills') {
            var bills = acc[info]
            if (bills !== '') {
               var cell = ws['M' + stt]
               if (!cell.c) ws['M' + stt].c = [];
               var comment_part = {
                  a: "smeta.vn",
                  t: bills
               };
               cell.c.hidden = true;
               cell.c.push(comment_part);
            }
            break;
         }
      }
      stt++
   }
   var ws1 = XLSX.utils.aoa_to_sheet(arrBM);
   ws1['!cols'] = fitToColumn(arrBM);
   wb.Sheets["TKQC"] = ws;
   wb.Sheets["BM"] = ws1;
   var wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

   function s2ab(s) {
      var buf = new ArrayBuffer(s.length); //convert s to arrayBuffer
      var view = new Uint8Array(buf);  //create uint8array as viewer
      for (var i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xFF; //convert to octet
      return buf;
   }
   const now = new Date();
   const time = now.toLocaleTimeString('vi-VN', { hour12: false, hour: 'numeric', minute: 'numeric' });
   const date = now.toLocaleDateString('vi-VN', { month: 'numeric', day: 'numeric' });
   var timeNow = time + ', ' + date;

   saveAs(new Blob([s2ab(wbout)], { type: "application/octet-stream" }), `sMeta TKQC (${timeNow}).xlsx`);
   alertGreen('Download thành công', 2000)
}

document.getElementById('btn_currency').addEventListener('click', function (e) {
   btn = document.getElementById("btn_currency")

   if (btn.style.backgroundColor == 'teal') {
      btn.style.backgroundColor = 'seagreen'
   } else {
      btn.style.backgroundColor = 'teal'
   }

   if (btn.style.backgroundColor == 'teal') {
      document.querySelectorAll('.r').forEach(function (el) {
         el.style.display = 'none';
      });
      document.querySelectorAll('.g').forEach(function (el) {
         el.style.display = 'inline';
      });
   } else {
      document.querySelectorAll('.r').forEach(function (el) {
         el.style.display = 'inline';
      });
      document.querySelectorAll('.g').forEach(function (el) {
         el.style.display = 'none';
      });
   }

})


document.getElementById('btn_menu').addEventListener('click', function (e) {
   var menu = document.getElementById('menu')
   if (menu.style.visibility != 'visible') {
      menu.style.visibility = "visible";
      menu.style.opacity = '1';

   } else {
      menu.style.visibility = "hidden";
      menu.style.opacity = '0';
   }

})

document.getElementsByClassName('main_form')[0].addEventListener('mousedown', function (e) {
   let fromLogin = document.getElementsByClassName('main_form')[0]
   if (e.target.matches('.main_form')) {
      fromLogin.style.display = "none"
   }
})


document.getElementById('login-back').addEventListener('click', () => {
   let fromLogin = document.getElementsByClassName('dangnhap')[0]
   let fromRegister = document.getElementsByClassName('dangky')[0]
   fromLogin.style.display = "flex"
   fromRegister.style.display = "none"
})

document.getElementById('menu-register').addEventListener('click', () => {
   let fromLogin = document.getElementsByClassName('dangnhap')[0]
   let fromRegister = document.getElementsByClassName('dangky')[0]
   fromLogin.style.display = "none"
   fromRegister.style.display = "flex"
})

function switchScreen(screenName) {
   var menu = document.getElementById('menu')
   var objScreen = {
      'screen1': document.getElementById('main'),
      'screen2': document.getElementById('screen-sharepixel'),
      'screen3': document.getElementById('screen-shareadacc'),
      'screen4': document.getElementById('screen-createbm'),
      'screen5': document.getElementById('setcamp'),
   }
   menu.style.visibility = "hidden";
   menu.style.opacity = '0';
   for (let screen in objScreen) {
      if (screen == screenName) {
         objScreen[screen].style.display = 'block'
      } else {
         objScreen[screen].style.display = 'none'
      }
   }
}


document.getElementById('home').addEventListener('click', function (e) {
   switchScreen('screen1')
})
document.getElementById('btn_show_sharepixel').addEventListener('click', function (e) {
   switchScreen('screen2')
   var listBM = document.getElementById('listBM').value
   renderPixel(listBM)
})
document.getElementById('btn_show_shareadacc').addEventListener('click', function (e) {
   switchScreen('screen3')
   // renderShareAdAcc()
})
document.getElementById('btn_show_createbm').addEventListener('click', function (e) {
   switchScreen('screen4')
   renderCreateBM()
})
document.getElementById('btn_show_setcamp').addEventListener('click', function (e) {
   switchScreen('screen5')
   renderADlist()
   renderPage()
})

async function renderShareAdAcc() {
   var table = document.getElementById('listAdAccCN')
   var objAds = await chrome.storage.local.get(['objAds'])
   objAds = JSON.parse(objAds.objAds)
   var objProperty = ['s_status', 's_id', 's_name', 's_currency']
   var result = ''
   for (var acc of objAds) {
      var text = ''
      if (acc.s_acctype != 'BM') {
         text += `
            <td>
               <input type="checkbox" class="ids" name="${acc[1]}" value="${acc[1]}">
            </td>
            <td>${acc[objProperty[0]]}</td>
            <td>${acc[objProperty[1]]}</td>
            <td>${acc[objProperty[2]]}</td>
            <td>${acc[objProperty[3]]}</td>
            `
      }
      if (text != '') {
         result += `<tr class="trads noselect">${text}</tr>`
      }
   }
   table.innerHTML = result
   var arrTr = document.getElementsByClassName('trads')
   var arrIds = document.getElementsByName('ids')
   handleSelect(arrTr)

}



async function renderCreateBM() {
   var listbm = document.getElementById('bm_id')
   var objBM = await chrome.storage.local.get('objBM')
   objBM = JSON.parse(objBM.objBM)
   var html = '<option>-</option>'
   for (var bm of objBM) {
      html += `<option value="${bm.s_id}lv${bm.s_levelBm}">${bm.s_id} |${bm.s_levelBm}| ${bm.s_limit}</option>`
   }
   listbm.innerHTML = html;
}


document.getElementById('btnShareTKQC').addEventListener('click', async function () {
   var auth = await smetaAuth('Share TKQC')
   if (!auth) { return alert('Vui lòng đăng nhập để sử dụng tính năng này', 2000) }
   var AdAccId = document.getElementById('stListAds').value;
   var role = document.getElementById('stRole').value;
   var listUserId = document.getElementById('stListUserId').value;
   var log = document.getElementById('logstatusshareadacc')
   let token = await chrome.storage.local.get(['token'])
   token = token.token

   var separators = ['\n', ',', ' ']
   var arrListTKQC = AdAccId.split(new RegExp(separators.join('|')));
   var arrListUser = listUserId.split(new RegExp(separators.join('|')));

   if (listUserId.length < 1 || arrListTKQC.length < 1) {
      alert('Vui lòng nhập thông tin', 3000)
      return
   }

   var logHtml = document.getElementById('logstatusshareadacc');
   logHtml.innerHTML = ''
   for (let tk of arrListTKQC) {
      for (let user of arrListUser) {
         if (tk.length > 0 || user.length > 0) {
            await ShareAdAcc(token, tk.trim(), user.trim(), role, log)
         }
      }
   }

});

document.getElementById('btnSharePixel').addEventListener('click', async function () {
   var auth = await smetaAuth('Share Pixel')
   if (!auth) { return alert('Vui lòng đăng nhập để sử dụng tính năng này', 2000) }
   var idBm = document.getElementById('listBM').value;
   var idPixel = document.getElementById('listPixel').value;
   var listPixelId = document.getElementById('listPixelId').value;
   let token = await chrome.storage.local.get(['token'])
   token = token.token

   var separators = ['\n', ',', ' ']
   var arrlistPixelId = listPixelId.split(new RegExp(separators.join('|')));

   if (listPixelId.length < 1) {
      alert('Vui lòng nhập ID TKQC', 3000)
      return
   }
   if (idPixel.slice(0, 2) != 'Do') {
      var logHtml = document.getElementById('logsatusSharePixel');
      logHtml.innerHTML = '';
      chrome.logHtml = ''

      for (var idAds of arrlistPixelId) {
         if (idAds.length != '') {
            SharePixel(token, idBm, idPixel, idAds.trim())
         }
      }
   } else {
      alert('Không có TKQC!', 3000)
      return;
   }
});

// bm_id
//changeBM
document.getElementById('bm_id').addEventListener('change', async () => {
   let token = await chrome.storage.local.get(['token'])
   var objBM = await chrome.storage.local.get('objBM')
   token = token.token
   objBM = JSON.parse(objBM.objBM)

   let bminfo = document.getElementById('bminfo')
   let currentBM = document.getElementById('bm_id')
   let bm_slot = document.getElementById('bm_slot')
   idbm = currentBM.value.split('lv')[0]
   bmlimit = currentBM.value.split('lv')[1]

   let html = ''

   for (let bm of objBM) {
      if (bm.s_id == idbm) {
         html = `<li>ID: ${bm.s_id}</li><li>Bm LV: ${bm.s_levelBm}</li><li>BM limit:${bm.s_limit}</li>`
         break
      }
   }
   bminfo.innerHTML = html

   let url = `https://graph.facebook.com/v15.0/${idbm}?fields=can_create_ad_account,owned_ad_accounts{id,currency,timezone_id}&access_token=` + token;
   let json = await reqAPI(url, 'GET')
   let obj = JSON.parse(json);
   let used = 0
   let currency = 'USD'
   let timezone = 1
   if ('owned_ad_accounts' in obj) {
      used = obj.owned_ad_accounts.data.length
      currency = obj.owned_ad_accounts.data[0].currency
      timezone = obj.owned_ad_accounts.data[0].timezone_id
   }
   bminfo.innerHTML += `<li id="_currency">Tiền tệ:${currency}</li><li id="_timezone">Múi giờ:${timezone}</li>`
   var slot = bmlimit - used
   bm_slot.value = slot
})

function fDelay(ms) {
   return new Promise(resolve => setTimeout(resolve, ms));
}


document.getElementById('btn_create_bm').addEventListener('click', async () => {
   var auth = await smetaAuth('Create Ad Account')
   if (!auth) { return alert('Vui lòng đăng nhập để sử dụng tính năng này', 2000) }
   var objBM = await chrome.storage.local.get('objBM')
   objBM = JSON.parse(objBM.objBM)
   var log = document.getElementById('log_createad')
   let currentBM = document.getElementById('bm_id').value
   let bm_slot = document.getElementById('bm_slot').value
   let bm_num = document.getElementById('bm_num').value
   let bm_name = document.getElementById('bm_name').value
   let delay = document.getElementById('bm_delay').value

   if (currentBM == '-') {
      alert('Vui lòng chọn BM muốn tạo TKQC', 3000)
      return
   }
   if (bm_slot < 1) {
      alert('Đã hết slot!', 3000)
      return
   }
   if (bm_num == '') {
      alert('Vui lòng nhập số lượng TKQC muốn tạo!', 3000)
      return
   }
   if (bm_slot < bm_num) {
      alert('không thể tạo nhiều tkqc hơn slot có sẵn!', 3000)
      return
   }
   if (bm_name == '') {
      alert('Vui lòng nhập tên TKQC!', 3000)
      return
   }
   if (delay == '') {
      alert('Vui lòng nhập thời gian chờ', 3000)
      return
   }

   var idbm = currentBM.split('lv')[0]
   var currency = document.getElementById('_currency').innerText.split(':')[1]
   var timezone = document.getElementById('_timezone').innerText.split(':')[1]
   log.innerHTML = ''
   for (let i = 0; i < bm_num; i++) {
      let name = bm_name + '_' + (i + 1)
      let result = await  (idbm, name, currency, timezone)
      let text = `<li>${name}: ${result}</li>`
      log.innerHTML = text + log.innerHTML
      await fDelay(delay * 1000);
   }
})



async function renderPage() {
   var selectFan = document.getElementById('page_select')
   let objFan = await chrome.storage.local.get(['objFan']);
   objFan = JSON.parse(objFan.objFan)
   var text = ''
   for (var fan of objFan) {
      text += `<li data="${fan.id}"><img src="${fan.img}"><span>${fan.name}</span></li>`
   }
   selectFan.innerHTML = text

   var page = document.querySelectorAll('.page li')
   page.forEach((page) => {
      var page1 = document.getElementById('page')
      var post1 = document.getElementById('post')
      page.onclick = () => {
         var tickPost = document.getElementById('tick_post').checked;
         page1.setAttribute('data', page.getAttribute('data'))
         page1.innerText = page.innerText
         post1.innerText = "Chọn bài viết"
         renderPost(page.getAttribute('data'), tickPost)
      }
      post1.onkeyup = () => {
         var idPost = document.getElementById('post')
         var tickPost = document.getElementById('tick_post').checked;
         if (idPost.value == '') {
            renderPost(page1.getAttribute('data'), tickPost)
         } else {
            renderOnePost(page1.getAttribute('data'), idPost.value)
         }
      }
   })

}

document.getElementById('tick_post').addEventListener('change', () => {
   var page = document.getElementById('page').getAttribute('data')
   var post = document.getElementById('post')
   var tickPost = document.getElementById('tick_post').checked;
   post.innerHTML = 'Chọn bài viết'
   if (page) {
      renderPost(page, tickPost)
   }
})

document.getElementById('tick_group').addEventListener('change', () => {
   var inputGroup = document.getElementById('group_number')
   var tickGroup = document.getElementById('tick_group').checked;
   if (tickGroup) {
      inputGroup.removeAttribute('disabled')
   } else {
      inputGroup.setAttribute('disabled', 'disabled')
   }
})

// document.getElementById('tick_rule').addEventListener('change', () => {
//    var tickGroup = document.getElementById('tick_rule').checked;
//    var mainRule = document.getElementById('main_rule')
//    if (tickGroup) {
//       mainRule.style.height = '50px'
//    } else {
//       mainRule.style.height = '0px'
//    }
// })

async function renderOnePost(page, idPost) {
   var selectPost = document.getElementById('post_select')
   let token = await chrome.storage.local.get(['token'])
   token = token.token

   let url = `https://graph.facebook.com/v15.0/${page}_${idPost}?fields=call_to_action,message,is_eligible_for_promotion,promotable_id,attachments.limit(10){description,description_tags,media,media_type,target,title,type,subattachments,unshimmed_url,url},likes.summary(total_count),shares,comments.summary(total_count).limit(0)&access_token=` + token;
   let json = await reqAPI(url, 'GET')
   let posts = JSON.parse(json);

   var html = ''

   if ('attachments' in posts) {
      // if ('attachments' in posts && (posts.is_eligible_for_promotion)) {
      var url_img = '/access/icon/popup.png'
      if ('media' in posts.attachments.data[0]) {
         var url_img = posts.attachments.data[0].media.image.src
      }
      let message = posts.message ? posts.message : 'Không có mô tả'
      let like = posts.likes.summary.total_count
      let cmt = posts.comments.summary.total_count
      let share = (posts.shares) ? posts.shares.count : 0
      html += `<li data="${posts.id}">
                     <img src="${url_img}">
                     <div>
                        <span>${message}</span>
                        <span>ID: ${posts.id.split('_')[1]}</span>
                        <span>Like: ${like} | cmt ${cmt} | share ${share}</span>
                     </div>
                  </li>`
   }

   if (html == '') {
      selectPost.innerHTML = `<li><span>Không có dữ liệu</span></li>`
   } else {
      selectPost.innerHTML = html
   }
   var post = document.querySelectorAll('.post li')
   post.forEach((post) => {
      var post1 = document.getElementById('post')
      post.onclick = () => {
         let id_post = post.getAttribute('data')
         post1.setAttribute('data', id_post)
         post1.value = id_post.split('_')[1]
         if (id_post) {
            handlerPostAdcreative(id_post)
         }
      }
   })
}


async function renderPost(page, flag) {
   var selectPost = document.getElementById('post_select')
   let token = await chrome.storage.local.get(['token'])
   token = token.token
   var endpoint = 'posts'
   if (flag) {
      endpoint = 'ads_posts'
   }
   let url = `https://graph.facebook.com/v15.0/${page}/${endpoint}?fields=call_to_action,message,is_eligible_for_promotion,promotable_id,attachments.limit(10){description,description_tags,media,media_type,target,title,type,subattachments,unshimmed_url,url},likes.summary(total_count),shares,comments.summary(total_count).limit(0)&access_token=` + token;
   let json = await reqAPI(url, 'GET')
   let objJSON = JSON.parse(json);
   var objListPost = objJSON.data
   var tempNext = objJSON.paging
   var html = ''
   for (var posts of objListPost) {
      if ('attachments' in posts) {
         var url_img = '/access/icon/popup.png'
         if ('media' in posts.attachments.data[0]) {
            var url_img = posts.attachments.data[0].media.image.src
         }
         let message = posts.message ? posts.message : 'Không có mô tả'
         let like = posts.likes.summary.total_count
         let cmt = posts.comments.summary.total_count
         let share = (posts.shares) ? posts.shares.count : 0
         html += `<li data="${posts.id}">
                     <img src="${url_img}">
                     <div>
                        <span>${message}</span>
                        <span>ID: ${posts.id.split('_')[1]}</span>
                        <span>Like: ${like} | cmt ${cmt} | share ${share}</span>
                     </div>
                  </li>`
      }
   }
   if (html == '') {
      selectPost.innerHTML = `<li><span>Không có dữ liệu</span></li>`
   } else {
      selectPost.innerHTML = html
   }
   var post = document.querySelectorAll('.post li')
   post.forEach((post) => {
      var post1 = document.getElementById('post')
      post.onclick = () => {
         let id_post = post.getAttribute('data')
         post1.setAttribute('data', id_post)
         post1.value = id_post.split('_')[1]
         if (id_post) {
            handlerPostAdcreative(id_post)
         }
      }
   })
}


async function renderADlist() {
   var ad_select = document.getElementById('ad-select')
   var objAds = await chrome.storage.local.get(['objAds'])
   objAds = JSON.parse(objAds.objAds)
   var html = ''
   var count = 0
   for (var acc of objAds) {
      if (acc.s_status !== 'Die') {
         html += `<option>${acc.s_id}</option>`
         if (count < 1) {
            ad_select.value = acc.s_id
            ad_select.dataset.bm = acc.s_bm
         }
         count++
      }
   }
   ad_select.innerHTML = html
   let act = ad_select.value
   renderRatio(act)
   renderPixel2(act)
}

async function renderRatio(act) {
   var objAds = await chrome.storage.local.get(['objAds'])
   objAds = JSON.parse(objAds.objAds)
   var usdRation = document.getElementsByClassName('usdratio')[0]
   var butget = document.getElementById('budget')
   butget.value = 20
   for (var acc of objAds) {
      if (acc.s_id == act) {
         var usdBack = 20 * acc.h_rate;
         usdRation.dataset.rate = acc.h_rate;
         usdRation.dataset.currency = acc.s_currency;
         usdRation.dataset.budgetusd = Math.round(butget.value);
         usdRation.dataset.budget = Math.round(usdBack);
         usdRation.innerHTML = `USD ~ ${mony(Math.round(usdBack), acc.s_currency)} ${acc.s_currency}`;
         break;
      }
   }
}

document.getElementById('budget').addEventListener('input', async (x) => {
   var act = document.getElementById('ad-select').value
   var butget = document.getElementById('budget').value
   var objAds = await chrome.storage.local.get(['objAds'])
   objAds = JSON.parse(objAds.objAds)
   var usdRation = document.getElementsByClassName('usdratio')[0]
   if (act == '' || butget == '') {
      butget = 0
   }
   for (var acc of objAds) {
      if (acc.s_id == act) {
         var usdBack = butget * acc.h_rate;
         usdRation.dataset.rate = acc.h_rate;
         usdRation.dataset.currency = acc.s_currency;
         usdRation.dataset.budgetusd = Math.round(butget);
         usdRation.dataset.budget = Math.round(usdBack);
         usdRation.innerHTML = `USD ~ ${mony(Math.round(usdBack), acc.s_currency)} ${acc.s_currency}`;
         break;
      }
   }
})

// document.getElementById('budgetMax').addEventListener('input', async (x) => {
//    var act = document.getElementById('ad-select').value
//    var butget = document.getElementById('budgetMax').value
//    var objAds = await chrome.storage.local.get(['objAds'])
//    objAds = JSON.parse(objAds.objAds)
//    var usdRation = document.getElementById('usdmaxratio')
//    if (act == '' || butget == '') {
//       butget = 0
//    }
//    for (var acc of objAds) {
//       if (acc.s_id == act) {
//          var usdBack = butget * acc.h_rate;
//          usdRation.dataset.rate = acc.h_rate;
//          usdRation.dataset.currency = acc.s_currency;
//          usdRation.dataset.budgetusd = Math.round(butget);
//          usdRation.dataset.budget = Math.round(usdBack);
//          usdRation.innerHTML = `USD ~ ${mony(Math.round(usdBack), acc.s_currency)} ${acc.s_currency}`;
//          break;
//       }
//    }
// })


document.getElementById('ad-select').addEventListener('change', async (e) => {
   var act = e.target.value
   var objAds = await chrome.storage.local.get(['objAds'])
   objAds = JSON.parse(objAds.objAds)
   var foundObj = objAds.find(obj => obj.s_id == act)
   e.target.dataset.bm = foundObj.s_bm
   renderPixel2(act)
   renderRatio(act)
})

// lấy danh sách pixel của BM 
async function renderPixel(currentBM) {
   var listPixel = document.getElementById('listPixel');
   let token = await chrome.storage.local.get(['token'])
   token = token.token
   let url = `https://graph.facebook.com/v15.0/${currentBM}?fields=owned_pixels{id,name}&access_token=${token}`
   let json = await reqAPI(url, 'GET')
   let obj = JSON.parse(json)
   var optionHTML = '';
   if ('owned_pixels' in obj) {
      for (var px of obj.owned_pixels.data) {
         optionHTML += `<option value='${px['id']}'>${px['id']} | ${px['name']}</option>`
      }
   } else {
      optionHTML += `<option>Dose have an account!</option>`
   }
   listPixel.innerHTML = optionHTML;
}



async function renderPixel2(act) {
   let pixel_select = document.getElementById('pixel-select')
   let token = await chrome.storage.local.get(['token'])
   token = token.token
   let url = `https://graph.facebook.com/v15.0/act_${act}/adspixels?fields=id,name&access_token=${token}`
   let json = await reqAPI(url, 'GET')
   let objJSON = JSON.parse(json);
   objJSON = objJSON.data
   var html = ''
   for (var pixel of objJSON) {
      html += `<option value=${pixel.id}>${pixel.name}</option>`
   }
   if (html == '') {
      pixel_select.innerHTML = `<option>No Pixel</option>`
      return
   }
   pixel_select.innerHTML = html
}




async function renderSetCamp() {
   var table = document.getElementById('listsetcamp')
   var objAds = await chrome.storage.local.get(['objAds'])
   objAds = JSON.parse(objAds.objAds)
   var objProperty = ['s_id', 's_balance', 's_threshold', 's_adtrust', 's_spent', 's_currency']
   var result = ''
   for (var acc of objAds) {
      var text = ''
      for (var info in acc) {
         if (acc.s_status == 'Active') {
            if (objProperty.includes(info)) {
               if (info == 's_id') {
                  text += `<td><input type="checkbox" class="ids" name="${acc[info]}" value="${acc[info]}"></td><td>${acc[info]}</td>`
               } else {
                  text += `<td>${acc[info]}</td>`
               }
            }
         }
      }
      if (text != '') {
         result += `<tr class="trads noselect">${text}</tr>`
      }
   }
   table.innerHTML = result
   var arrTr = document.getElementsByClassName('trads')
   var arrIds = document.getElementsByName('ids')
   handleSelect(arrTr)
}

function handleSelect(arrTr) {
   for (var i = 0; i < arrTr.length; i++) {
      arrTr[i].addEventListener('click', function (e) {
         var rb = this.querySelector('input')
         if (rb.checked) {
            rb.checked = false
         } else {
            rb.checked = true
         }

         handler()
      })
   }
}

function handler() {
   var arrInput = document.getElementsByClassName('ids')
   var text_select = document.getElementById('text_select')
   var arrAdsAcc = []
   for (var i = 0; i < arrInput.length; i++) {
      var check = arrInput[i].checked
      if (check) {
         arrAdsAcc.push(arrInput[i].value)
      }
   }
   chrome.storage.local.set({ 'selectacc': arrAdsAcc });
   text_select.innerHTML = `Đã chọn ${arrAdsAcc.length} TK`
}


document.getElementById('selectAll').addEventListener('click', function () {
   var check = document.getElementById('selectAll')
   var arrInput = document.getElementsByClassName('ids')
   var text_select = document.getElementById('text_select')
   var arrAdsAcc = []
   if (check.checked) {
      for (var i = 0; i < arrInput.length; i++) {
         arrInput[i].checked = true
         arrAdsAcc.push(arrInput[i].value)
      }
   } else {
      for (var i = 0; i < arrInput.length; i++) {
         arrInput[i].checked = false
      }
   }

   chrome.storage.local.set({ 'selectacc': arrAdsAcc });
   text_select.innerHTML = `Đã chọn ${arrAdsAcc.length} TK`
})

document.getElementById('post_action').addEventListener('change', () => {
   var action = document.getElementById('post_action').value
   var textPosistion = document.getElementById('t_posistion')
   if (action == 'LEARN_MORE') {
      textPosistion.innerText = 'Tự động Advantage+'
   } else {
      textPosistion.innerText = 'Feed, Video Feed, Reels'
   }
})

async function handlerPostAdcreative(idpost) {
   var textPosistion = document.getElementById('t_posistion')
   var post_title = document.getElementById('post_title')
   var post_message = document.getElementById('post_message')
   var post_action = document.getElementById('post_action')
   var post_link = document.getElementById('post_link')
   let token = await chrome.storage.local.get(['token'])
   token = token.token

   let url = `https://graph.facebook.com/v15.0/${idpost}?fields=call_to_action,message,is_eligible_for_promotion,promotable_id,attachments.limit(10){description,description_tags,media,media_type,target,title,type,subattachments,unshimmed_url,url}&access_token=` + token;
   let json = await reqAPI(url, 'GET')
   let objJSON = JSON.parse(json);

   let media = objJSON.attachments.data[0]
   let title = (media.title) ? media.title : 'Không có tiêu đề'
   let message = objJSON.message ? objJSON.message : 'Không có mô tả'
   let actionType = (objJSON.call_to_action) ? objJSON.call_to_action : false

   post_link.removeAttribute("disabled")
   post_action.removeAttribute("disabled")
   post_action.innerHTML = `<option value="SHOP_NOW">SHOP_NOW</option>`
   post_link.value = ''

   if (actionType) {
      let type = actionType.type
      let url = actionType.value.link ? actionType.value.link : ''
      if (type != 'NO_BUTTON') {
         post_action.innerHTML = `<option value="${type}">${type}</option>`
         post_action.setAttribute("disabled", "disabled")
      }
      if (url !== '') {
         post_link.setAttribute("disabled", "disabled")
      }
      post_link.value = url

   }
   post_title.value = title
   post_message.innerText = message
   post_title.setAttribute("disabled", "disabled")
   post_message.setAttribute("disabled", "disabled")
}

window.alertGreen = function (message, timeout = null) {
   const alert = document.createElement('div')
   const alertButton = document.createElement('button')
   alertButton.innerHTML = 'OK'
   alert.classList.add('alert_green')
   alert.innerHTML = `<span >${message}</span>`
   alertButton.addEventListener('click', (e) => {
      alert.remove()
   })
   if (timeout != null) {
      setTimeout(() => {
         alert.remove()
      }, Number(timeout))
      document.body.appendChild(alert)
   }
}

window.alert = function (message, timeout = null) {
   const alert = document.createElement('div')
   const alertButton = document.createElement('button')
   alertButton.innerHTML = 'OK'
   alert.classList.add('alert')
   alert.innerHTML = `<span>${message}</span>`
   alert.appendChild(alertButton)
   alertButton.addEventListener('click', (e) => {
      alert.remove()
   })
   if (timeout != null) {
      setTimeout(() => {
         alert.remove()
      }, Number(timeout))
   }
   document.body.appendChild(alert)
}


function handlerEventTable() {

   thall = document.querySelectorAll('#thall th')
   thall.forEach((head, i) => {

      head.onclick = () => {
         tb = document.getElementById('tball')
         var flag = head.classList.value
         thall.forEach(head => head.classList.remove('az'))
         thall.forEach(head => head.classList.remove('za'))
         thall.forEach(head => head.classList.remove('sort'))
         if (flag == '') {
            head.classList.add('az')
            sortTable(tb, i, 'az')
         } else if (flag == 'az' || flag == 'sort az') {
            head.classList.add('za')
            sortTable(tb, i, 'za')
         } else {
            head.classList.add('az')
            sortTable(tb, i, 'az')
         }
      }
   })

   thBMall = document.querySelectorAll('#thBMall th')
   thBMall.forEach((head, i) => {

      head.onclick = () => {
         tb = document.getElementById('tbBMall')
         var flag = head.classList.value
         thBMall.forEach(head => head.classList.remove('az'))
         thBMall.forEach(head => head.classList.remove('za'))
         thBMall.forEach(head => head.classList.remove('sort'))
         if (flag == '') {
            head.classList.add('az')
            sortTable(tb, i, 'az')
         } else if (flag == 'az' || flag == 'sort az') {
            head.classList.add('za')
            sortTable(tb, i, 'za')
         } else {
            head.classList.add('az')
            sortTable(tb, i, 'az')
         }
      }
   })

   thFanPageall = document.querySelectorAll('#thFanPageall th')
   thFanPageall.forEach((head, i) => {

      head.onclick = () => {
         tb = document.getElementById('tbFanPageall')
         var flag = head.classList.value
         thFanPageall.forEach(head => head.classList.remove('az'))
         thFanPageall.forEach(head => head.classList.remove('za'))
         thFanPageall.forEach(head => head.classList.remove('sort'))
         if (flag == '') {
            head.classList.add('az')
            sortTable(tb, i, 'az')
         } else if (flag == 'az' || flag == 'sort az') {
            head.classList.add('za')
            sortTable(tb, i, 'za')
         } else {
            head.classList.add('az')
            sortTable(tb, i, 'az')
         }
      }
   })

   thCampall = document.querySelectorAll('#thCampall th')
   thCampall.forEach((head, i) => {
      head.onclick = () => {
         tb = document.getElementById('tbCampall')
         var flag = head.classList.value
         thCampall.forEach(head => head.classList.remove('az'))
         thCampall.forEach(head => head.classList.remove('za'))
         thCampall.forEach(head => head.classList.remove('sort'))
         if (flag == '') {
            head.classList.add('az')
            sortTable(tb, i, 'az')
         } else if (flag == 'az' || flag == 'sort az') {
            head.classList.add('za')
            sortTable(tb, i, 'za')
         } else {
            head.classList.add('az')
            sortTable(tb, i, 'az')
         }
      }
   })

   var dropdown = document.querySelectorAll('.drop_btn')
   dropdown.forEach((drop, i) => {
      drop.onclick = () => {
         let checkshow = drop.nextElementSibling.classList.length
         if (checkshow == 1) {
            var droplist = document.querySelectorAll('.drop_list')
            droplist.forEach((list) => {
               list.classList.remove('drop_show')
            })
            drop.nextElementSibling.classList.add('drop_show')
            return
         }
         var droplist = document.querySelectorAll('.drop_list')
         droplist.forEach((list) => {
            list.classList.remove('drop_show')
         })
      }
   })
   var link_ads = document.querySelectorAll('.link-ads')
   link_ads.forEach((link) => {
      link.onclick = () => {
         let type = link.getAttribute('type')
         switch (type) {
            case 'ad':
               var id = link.getAttribute('data')
               chrome.tabs.create({ url: 'https://adsmanager.facebook.com/adsmanager/manage/campaigns?act=' + id, active: false });
               break
            case 'bm':
               chrome.tabs.create({ url: 'https://business.facebook.com/settings/ad-accounts?business_id=' + link.innerText, active: false });
               break
            case 'bill':
               var id = link.getAttribute('data')
               chrome.tabs.create({ url: 'https://adsmanager.facebook.com/ads/manager/account_settings/account_billing/?act=' + id, active: false });
               break
            case 'fan':
               chrome.tabs.create({ url: 'https://facebook.com/' + link.innerText, active: false });
               break

         }
      }
   })

   var show_admin = document.querySelectorAll('.show-admin')
   show_admin.forEach((button) => {
      button.onclick = () => {
         renderListAdminHide(button.dataset.type, button.dataset.id, button.dataset.bemo)
      }
   })

}

async function renderListAdminHide(type, id, bm) {
   var model = document.createElement('div')
   var loading = document.createElement('div')
   var adminDiv = document.createElement('div')
   model.classList.add('model')
   loading.classList.add('load_model')
   adminDiv.classList.add('admin-div')
   loading.innerHTML = '<img src="access/icon/loadingdata.gif" alt="loading...">'
   adminDiv.appendChild(loading)
   model.appendChild(adminDiv)
   document.body.appendChild(model)
   model.addEventListener('mousedown', function (e) {
      if (e.target.matches('.model')) {
         model.remove()
      }
   })
   var arrListAdmin = []
   if (type == 'ad') {
      arrListAdmin = await getListAdminAdHide(id, bm)
   } else {
      arrListAdmin = await getListAdminBmHide(id)
   }
   var liHtml = ''
   var countHide = 0
   for (let user of arrListAdmin) {
      let text = '<i class="fa-solid fa-circle-check fa-sm" style="color: #00c203"></i><span>Active</span>'

      if (user.isAdminHide) {
         text = '<i class="fa-solid fa-triangle-exclamation fa-sm" style="color: #ff7b00;"></i><span>QTV ẩn</span>'
         countHide += 1
      }
      liHtml += `
      <li> 
         <input type="checkbox" name="selectacc" data-id=${id} data-user=${user.id} data-type=${type} />
         <div style="width:35%">
            <span style="display:block;font-weight: bold;">${user.name} </span>
            <span>${user.id} </span>
         </div>
         <div style="width:20%">
            <span>${user.role}</span>
         </div>
         <div style="width:25%">
            ${text}
         </div>
         <div style="width:20%;">
            <div class="btn_remove_admin"  data-id=${id} data-user=${user.id} data-type=${type}>
               <i class="fa-solid fa-trash-can fa-sm"></i>
               <span>Remove</span>
            </div>
         </div>
      </li>
      `
   }
   adminDiv.innerHTML = `
      <span class="titleAdmin">AD ID: ${id} - Admin: ${arrListAdmin.length} (${countHide})</span>
   <div class="listEAAG">
      <ul>
      <li class="headerListUser" style="padding: 5px 5px;"> 
      <input type="checkbox" id="selectAllUser"/>
      <div style="width:35%">
         <span style="display:block;font-weight: bold;">Name</span>
      </div>
      <div style="width:20%">
         <span>Role</span>
      </div>
      <div style="width:25%"><span>Status</span></div>
      <div style="width:20%;" id="haveSelect">
         <i class="fa-solid fa-trash-can fa-sm"></i>
         <span> Remove (0)</span>
      </div>
   </li>
      ${liHtml}
      </ul>
   </div>
   `
   btnSelctAll = model.querySelector('#selectAllUser')
   checkboxlist = model.querySelectorAll('[name]')
   haveSelect = model.querySelector('#haveSelect')
   btnSelctAll.onclick = () => {
      checkboxlist.forEach((box) => {
         if (btnSelctAll.checked) {
            box.checked = true
         } else {
            box.checked = false
         }
         let count = model.querySelectorAll('[name]:checked').length
         haveSelect.innerHTML = `<i class="fa-solid fa-trash-can fa-sm"></i><span> Remove (${count})</span>`
      })
   }

   checkboxlist.forEach((box) => {
      box.onclick = () => {
         let count = model.querySelectorAll('[name]:checked').length
         haveSelect.innerHTML = `<i class="fa-solid fa-trash-can fa-sm"></i><span> Remove (${count})</span>`
      }
   })
   haveSelect.onclick = async () => {
      var answer = window.confirm("Bạn chắc chắn muốn xóa những QTV đã chọn không");
      if (!answer) {
         return
      }
      var auth = await smetaAuth('Remove Admin Select')
      if (!auth) { return alert('Vui lòng đăng nhập để sử dụng tính năng này', 2000) }
      checkboxlist.forEach(async (box) => {
         var id = box.dataset.id
         var user_id = box.dataset.user
         var type = box.dataset.type
         if (box.checked) {
            if (type == 'ad') {
               result = await removeAdminAD(id, user_id)
            } else {
               result = await removeAdminBM(user_id)
            }
         }
      })
      alertGreen('Hoàn thành', 3000)
      model.remove()
      renderListAdminHide(type, id, bm)
   }

   listAdRemove = model.querySelectorAll('.btn_remove_admin')
   listAdRemove.forEach((ad) => {
      ad.onclick = async () => {
         var id = ad.dataset.id
         var user_id = ad.dataset.user
         var type = ad.dataset.type
         if (type == 'bm') {
            var answer = window.confirm("Bạn chắc chắn muốn xóa QTV này ra khỏi BM không?");
            if (!answer) {
               return
            }
            var auth = await smetaAuth('Remove Admin BM')
            if (!auth) { return alert('Vui lòng đăng nhập để sử dụng tính năng này', 2000) }
         } else {
            var answer = window.confirm("Bạn chắc chắn muốn xóa User này ra khỏi TKQC không?");
            if (!answer) {
               return
            }
            var auth = await smetaAuth('Remove Admin AD')
            if (!auth) { return alert('Vui lòng đăng nhập để sử dụng tính năng này', 2000) }
         }
         var result
         if (type == 'ad') {
            result = await removeAdminAD(id, user_id)
         } else {
            result = await removeAdminBM(user_id)
         }
         if ('success' in result) {
            alertGreen('Xóa thành công!', 3000)
            model.remove()
            renderListAdminHide(type, id, bm)
         } else {
            alert(result.error.message)
         }
      }
   })
}

async function getListAdminAdHide(id, bm) {
   let tempLocal = await chrome.storage.local.get(['token', 'tokenEAAG'])
   let token = tempLocal.token
   let tokenEAAG = tempLocal.tokenEAAG
   var url = `https://www.facebook.com/ads/manager/account_settings/information/?act=${id}`
   if (bm != '-') {
      url = `https://business.facebook.com/ads/manager/account_settings/information/?act=${id}&business_id=${bm}`
   }
   let res = await reqAPI(url, 'GET')
   let textSplit = res.split('accountUsers:')[1].split(',adColumnSizes')[0]
   let json = textSplit.replace(/([a-zA-Z0-9]+?):/g, '"$1":')
   let arr = JSON.parse(json)
   var arrResult = []
   for (var user of arr) {
      var obj = {}
      obj.id = user.id
      obj.name = user.name ? user.name : 'Ẩn danh'
      if (user.role == '281423141961500') {
         obj.role = 'Quản trị viên'
      } else if (user.role == '461336843905730') {
         obj.role = 'Nhà phân tích'
      } else if (user.role == '498940650138739') {
         obj.role = 'Nhà quảng cáo'
      } else {
         obj.role = 'Không xác định'
      }
      obj.isAdminHide = user.name ? false : true
      arrResult.push(obj)
   }
   return arrResult
}

async function getListAdminBmHide(id) {
   let tempLocal = await chrome.storage.local.get(['token', 'tokenEAAG'])
   let token = tempLocal.token
   let tokenEAAG = tempLocal.tokenEAAG
   let url = `https://graph.facebook.com/v14.0/${id}/business_users?&fields=first_name,last_name,id,role`
   let resEAAB = await reqAPI(url + `&access_token=${token}`, 'GET')
   let resEAAG = await reqAPI(url + `&access_token=${tokenEAAG}`, 'GET')
   let jsonEAAB = JSON.parse(resEAAB);
   let jsonEAAG = JSON.parse(resEAAG);

   let adminEAAB = jsonEAAB.data
   let adminEAAG = jsonEAAG.data
   const ids = adminEAAG.map(e => e.id);
   var arrResult = []
   for (let user of adminEAAB) {
      let obj = {}
      obj.id = user.id
      obj.name = `${user.first_name} ${user.last_name}`
      obj.role = user.role
      obj.isAdminHide = !ids.includes(user.id)
      arrResult.push(obj)
   }
   return arrResult
}

function sortAz(a, b) {
   if (isNaN(a) || isNaN(b)) {
      return a.toString().localeCompare(b.toString());
   } else {
      return a - b;
   }
}


function sortZa(a, b) {
   if (isNaN(a) || isNaN(b)) {
      return b.toString().localeCompare(a.toString());
   } else {
      return b - a;
   }
}

function sortTable(table, col, aza) {
   var aza = aza
   var tb = table.tBodies[0],
      tr = Array.prototype.slice.call(tb.rows, 0)

   tr = tr.sort(function (a, b) {
      let tdA = a.cells[col]
      let tdB = b.cells[col]
      let flagX = tdA.getElementsByClassName('r').length

      if (flagX > 0) {
         var flagDisplay = tdA.getElementsByClassName('r')[0].style.display
         if (flagDisplay != 'none') {
            var aa = tdA.getElementsByClassName('r')[0].getAttribute('value')
            var bb = tdB.getElementsByClassName('r')[0].getAttribute('value')
         } else {
            var aa = tdA.getElementsByClassName('g')[0].getAttribute('value')
            var bb = tdB.getElementsByClassName('g')[0].getAttribute('value')
         }
      } else {
         var aa = tdA.textContent
         var bb = tdB.textContent
      }
      if (aza == 'az') {
         return sortAz(aa, bb)
      } else {
         return sortZa(aa, bb)
      }

   });

   for (i = 0; i < tr.length; ++i) tb.appendChild(tr[i]);
}

window.onclick = (e) => {
   var droplist = document.querySelectorAll('.drop_list')
   if (droplist && !e.target.matches('.drop_btn')) {
      droplist.forEach((list) => {
         list.classList.remove('drop_show')
      })
   }
   var menu = document.querySelectorAll('.menu')
   if (menu && !e.target.matches('.menux') && !e.target.closest('.menu')) {
      menu[0].style.visibility = "hidden";
      menu[0].style.opacity = '0';
   }
}

document.getElementById('btn-set-camp').addEventListener('click', async function () {
   var auth = await smetaAuth('Set Camp Auto')
   if (!auth) { return alert('Vui lòng đăng nhập để sử dụng tính năng này', 2000) }
   let token = await chrome.storage.local.get(['token']); token = token.token
   const data = {
      token: token,
      // logger: document.getElementById('logger'),
      // logger_li: document.getElementById('logger-li'),
      // act_id: document.getElementById('ad-select').value,
      act_bm: document.getElementById('ad-select').dataset.bm,
      // page_id: document.getElementById('page').getAttribute('data'),
      // post_id: document.getElementById('post').getAttribute('data'),
      // url_video: document.getElementById('url_video').value,
      // url_thumb: document.getElementById('url_thumb').value,
      // title: document.getElementById('post_title').value,
      // content: document.getElementById('post_message').value,
      // action: document.getElementById('post_action').value,
      // action_link: document.getElementById('post_link').value,
      // action_flag: document.getElementById('post_link').getAttribute("disabled"),
      // pixel: document.getElementById('pixel-select').value,
      // posistion: document.getElementById('radio_posistion_auto').checked,
      // budget: document.getElementById('usdratio').dataset.budget,
      // currency: document.getElementById('usdratio').dataset.currency,
      // gender: document.getElementById('gender').value,
      // min_age: document.getElementById('min-age').value,
      // max_age: document.getElementById('max-age').value,
      // name: document.getElementById('campName').value,
      // copyGroup: document.getElementById('tick_group').checked,
      // tick_rule: document.getElementById('tick_rule').checked,
      // numberGroup: document.getElementById('group_number').value,
      // defaultGroup: 1,
   }
   // const isDRAFT = document.getElementById('tick_draft').checked
   // const TYPE = document.getElementById('radio_post').checked

   if (isDRAFT) {
      if (TYPE) {
         setCampPostDraft(data)
      } else {
         setCampUploadDraft(data)
      }
   } else {
      if (TYPE) {
         setCampPost(data)
      } else {
         setCampUpload(data)
      }
   }
})

function validationPost(data) {
   if (data.page_id === null) {
      alert('Vui lòng chọn một Page', 3000)
      return false
   }
   if (data.post_id === null) {
      alert('Vui lòng chọn một Post', 3000)
      return false
   }
   if (data.pixel == '' || data.pixel == 'No Pixel') {
      alert('Vui lòng chọn data.pixel', 3000)
      return false
   }
   if (data.action_link == '') {
      alert('Vui lòng nhập link website', 3000)
      return false
   }
   if (data.name == '') {
      alert('Vui lòng nhập tên chiến dịch', 3000)
      return false
   }
   return true
}

async function setCampPostDraft(data) {
   const validate = validationPost(data)
   if (!validate) {
      return
   }

   data.logger.style.display = 'flex'
   data.logger_li.innerHTML = ''
   await turnOffNotify(data.act_id)
   data.logger_li.innerHTML += `<li>${data.act_id}: Đã tắt thông báo TKQC` + data.logger_li.innerHTML

   if (data.action_flag == null) {
      let post_id = data.post_id.split('_')[1]
      let add_action = await addCallActionType(post_id, data)
   }

   data.logger_li.innerHTML = `<li>${data.act_id}:Đang khởi tạo</li>` + data.logger_li.innerHTML
   var draft_id = await getDraftId(data.act_id, data.act_bm)
   if (draft_id == 'error') {
      data.logger_li.innerHTML = `<li>${data.act_id}:Khởi tạo camp draft lỗi</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}:Khởi tạo thành công</li>` + data.logger_li.innerHTML
   var campaign_id = await createCampDraft(draft_id, data)
   if (campaign_id == 'error') {
      data.logger_li.innerHTML = `<li>${data.act_id}:Tạo campain sảy ra lỗi</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}:Tạo campain thành công</li>` + data.logger_li.innerHTML
   var adset_id = await createAdGroupDraft(draft_id, campaign_id, data)
   if (adset_id == 'error') {
      data.logger_li.innerHTML = `<li>${data.act_id}:Tạo nhóm sảy ra lỗi</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}:Tạo nhóm thành công</li>` + data.logger_li.innerHTML
   var ads = await createAdsDraft(draft_id, campaign_id, adset_id, data)
   if (ads == 'error') {
      data.logger_li.innerHTML = `<li>${data.act_id}:Tạo nhóm sảy ra lỗi</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}:Hoàn tất</li>` + data.logger_li.innerHTML
   return
}

async function setCampPost(data) {
   const validate = validationPost(data)
   if (!validate) {
      return
   }

   data.logger.style.display = 'flex'
   data.logger_li.innerHTML = ''
   await turnOffNotify(data.act_id)
   data.logger_li.innerHTML += `<li>${data.act_id}: Đã tắt thông báo TKQC` + data.logger_li.innerHTML
   if (data.action_flag == null) {
      let post_id = data.post_id.split('_')[1]
      let add_action = await addCallActionType(post_id, data)
   }

   const now = new Date();
   const time = now.toLocaleTimeString('vi-VN', { hour12: false, hour: 'numeric', minute: 'numeric' });
   const date = now.toLocaleDateString('vi-VN', { month: 'numeric', day: 'numeric' });
   var timeNow = time + ', ' + date;
   if (data.copyGroup) {
      if (data.numberGroup > 1 && data.numberGroup <= 10) {
         data.defaultGroup = data.numberGroup
         data.budget = Math.round(data.budget / data.numberGroup)
      } else {
         alert('Chỉ cho phép nhân nhóm từ 2-10 nhóm', 2000)
         return
      }
   }
   var campaign = await createCamp(data)
   if ('error' in campaign) {
      data.logger_li.innerHTML = `<li>${data.act_id}:Camp: ${campaign.error.error_user_msg}</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}: Tạo camp thành công</li>` + data.logger_li.innerHTML
   let adcreative = await createAdcreative(data)
   if ('error' in adcreative) {
      data.logger_li.innerHTML = `<li>${data.act_id}: Creative=> ${adcreative.error.message}, ${adcreative.error.error_user_msg}</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}: Tạo nội dung qc thành công</li>` + data.logger_li.innerHTML
   for (let n = 1; n <= data.defaultGroup; n++) {
      let AdSet = await createAdGroup(campaign.id, data)
      if ('error' in AdSet) {
         data.logger_li.innerHTML += `<li>${data.act_id}:Adset: ${AdSet.error.error_user_msg}</li>` + data.logger_li.innerHTML
         return
      }
      data.logger_li.innerHTML = `<li>${data.act_id}: Tạo nhóm thành công *${n}</li>` + data.logger_li.innerHTML

      let ads = await createAds(AdSet.id, adcreative.id, data)
      if ('error' in ads) {
         data.logger_li.innerHTML = `<li>${data.act_id}: ADS=> ${ads.error.message}, ${ads.error.error_user_msg}</li>` + data.logger_li.innerHTML
         return
      }
      data.logger_li.innerHTML = `<li>${data.act_id}: Tạo ads thành công *${n}</li>` + data.logger_li.innerHTML
   }
   let ruleResult = await createRule(data.act_id, campaign.id)
   data.logger_li.innerHTML = `<li>${data.act_id}: ${ruleResult}` + data.logger_li.innerHTML
   if (data.tick_rule) {
      let budgetUp = document.getElementById('budgetUp').value
      let budgetMax = document.getElementById('usdratio').dataset.data.budget
      let result = await createRuleBudget(data.act_id, campaign.id, budgetUp, budgetMax)
      data.logger_li.innerHTML = `<li>${data.act_id}: ${result}` + data.logger_li.innerHTML
   }
   return
}

function validationUpload(data) {
   if (data.page_id === null) {
      alert('Vui lòng chọn một Page', 3000)
      return false
   }
   if (data.pixel == '' || data.pixel == 'No Pixel') {
      alert('Vui lòng chọn data.pixel', 3000)
      return false
   }
   if (data.url_video == '' || data.url_thumb == '' || data.title == '' || data.content == '' || data.action_link == '') {
      alert('Vui lòng nhập đầy đủ thông tin', 3000)
      return false
   }
   if (data.name == '') {
      alert('Vui lòng nhập tên chiến dịch', 3000)
      return false
   }
   return true
}

async function setCampUploadDraft(data) {
   const validate = validationUpload(data)
   if (!validate) {
      return
   }

   data.logger.style.display = 'flex'
   data.logger_li.innerHTML = ''
   await turnOffNotify(data.act_id)
   data.logger_li.innerHTML += `<li>${data.act_id}: Đã tắt thông báo TKQC` + data.logger_li.innerHTML


   data.logger_li.innerHTML = `<li>${data.act_id}:Đang khởi tạo</li>` + data.logger_li.innerHTML
   var draft_id = await getDraftId(data.act_id, data.act_bm)
   if (draft_id == 'error') {
      data.logger_li.innerHTML = `<li>${data.act_id}:Khởi tạo camp draft lỗi</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}:Khởi tạo thành công</li>` + data.logger_li.innerHTML
   var campaign_id = await createCampDraft(draft_id, data)
   if (campaign_id == 'error') {
      data.logger_li.innerHTML = `<li>${data.act_id}:Tạo campain sảy ra lỗi</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}:Tạo campain thành công</li>` + data.logger_li.innerHTML
   var adset_id = await createAdGroupDraft(draft_id, campaign_id, data)
   if (adset_id == 'error') {
      data.logger_li.innerHTML = `<li>${data.act_id}:Tạo nhóm sảy ra lỗi</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}:Tạo nhóm thành công</li>` + data.logger_li.innerHTML
   data.logger_li.innerHTML = `<li>${data.act_id}:Đang tải lên media</li>` + data.logger_li.innerHTML
   var AdVideo = await upLoadVideo(data)
   if ('error' in AdVideo) {
      data.logger_li.innerHTML = `<li>${data.act_id}:Media: ${AdVideo.error.error_user_msg}</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}:Tải lên video thành công</li>` + data.logger_li.innerHTML
   var AdThumb = await uploadThumb(data)
   if (AdThumb == 'error') {
      data.logger_li.innerHTML = `<li>${data.act_id}:Có lỗi khi tải lên thumbnail vui lòng kiểm tra lại</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}:Tải lên thumbnail thành công</li>` + data.logger_li.innerHTML
   var ads = await createAdsUploadDraft(draft_id, campaign_id, adset_id, AdVideo.id, AdThumb, data)
   if (ads == 'error') {
      data.logger_li.innerHTML = `<li>${data.act_id}:Ads: Sảy ra lỗi</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}:Hoàn tất</li>` + data.logger_li.innerHTML
   return
}

async function setCampUpload(data) {
   const validate = validationUpload(data)
   if (!validate) {
      return
   }

   data.logger.style.display = 'flex'
   data.logger_li.innerHTML = ''
   await turnOffNotify(data.act_id)
   data.logger_li.innerHTML += `<li>${data.act_id}: Đã tắt thông báo TKQC` + data.logger_li.innerHTML
   if (data.copyGroup) {
      if (data.numberGroup > 1 && data.numberGroup <= 10) {
         data.defaultGroup = data.numberGroup
         data.budget = Math.round(data.budget / data.numberGroup)
      } else {
         alert('Chỉ cho phép nhân nhóm từ 2-10 nhóm', 2000)
         return
      }
   }

   var campaign = await createCamp(data)
   if ('error' in campaign) {
      data.logger_li.innerHTML = `<li>${data.act_id}:Camp: ${campaign.error.error_user_msg}</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}: Tạo camp thành công</li>` + data.logger_li.innerHTML
   data.logger_li.innerHTML = `<li>${data.act_id}: Đang tải lên media</li>` + data.logger_li.innerHTML

   let AdVideo = await upLoadVideo(data)
   if ('error' in AdVideo) {
      data.logger_li.innerHTML = `<li>${data.act_id}: Video=> ${AdVideo.error.message}, ${AdVideo.error.error_user_msg}</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}: Tải lên media thành công</li>` + data.logger_li.innerHTML

   let AdCreative = await createAdcreativeUpload(data, AdVideo.id)
   if ('error' in AdCreative) {
      data.logger_li.innerHTML = `<li>${data.act_id}: Creative=> ${AdCreative.error.message}, ${AdCreative.error.error_user_msg}</li>` + data.logger_li.innerHTML
      return
   }
   data.logger_li.innerHTML = `<li>${data.act_id}: Tạo nội dung qc thành công</li>` + data.logger_li.innerHTML
   for (let n = 1; n <= data.defaultGroup; n++) {
      let AdSet = await createAdGroup(campaign.id, data)
      if ('error' in AdSet) {
         data.logger_li.innerHTML += `<li>${data.act_id}:Adset: ${AdSet.error.error_user_msg}</li>` + data.logger_li.innerHTML
         return
      }
      data.logger_li.innerHTML = `<li>${data.act_id}: Tạo nhóm thành công *${n}</li>` + data.logger_li.innerHTML

      let Ads = await createAds(AdSet.id, AdCreative.id, data)
      if ('error' in Ads) {
         data.logger_li.innerHTML = `<li>${data.act_id}: ADS=> ${Ads.error.message}, ${Ads.error.error_user_msg}</li>` + data.logger_li.innerHTML
         return
      }
      data.logger_li.innerHTML = `<li>${data.act_id}: Tạo ads thành công *${n}</li>` + data.logger_li.innerHTML
   }
   let ruleResult = await createRule(data.act_id, campaign.id)
   data.logger_li.innerHTML = `<li>${data.act_id}: ${ruleResult}` + data.logger_li.innerHTML
   if (data.tick_rule) {
      let budgetUp = document.getElementById('budgetUp').value
      let budgetMax = document.getElementById('usdratio').dataset.data.budget
      let result = await createRuleBudget(data.act_id, campaign.id, budgetUp, budgetMax)
      data.logger_li.innerHTML = `<li>${data.act_id}: ${result}` + data.logger_li.innerHTML
   }

}


document.getElementById('btn-logger').addEventListener('click', () => {
   var logger = document.getElementById('logger')
   logger.style.display = 'none'
})

function filterTable(table, filter) {
   var tr, td, i;
   tr = table.getElementsByTagName("tr");
   for (var i = 1; i < tr.length; i++) {
      var tds = tr[i].getElementsByTagName("td");
      var flag = false;
      for (var j = 0; j < tds.length; j++) {
         var td = tds[j];
         if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
            flag = true;
         }
      }
      if (flag) {
         tr[i].style.display = "";
      }
      else {
         tr[i].style.display = "none";
      }
   }
}

document.getElementById('tbfilter').addEventListener('keyup', (e) => {
   var input = document.getElementById("tbfilter");
   var filter = input.value.toUpperCase();
   let listTabs = document.querySelectorAll('.tabcontent')
   listTabs.forEach((tab) => {
      let flag = tab.classList.value.indexOf('active')
      if (flag > 0) {
         let table = tab.querySelector('table')
         filterTable(table, filter)
      }
   })

})

document.getElementsByClassName('telegram')[0].addEventListener('click', () => {
   chrome.tabs.create({
      'url': "https://t.me/smetasupport"
   });

})

document.querySelectorAll('.fa-house').forEach(element => {
   element.onclick = () => {
      var menu = document.getElementById('menu')
      var main = document.getElementById('main')
      var sharepixel = document.getElementById('screen-sharepixel')
      var createbm = document.getElementById('screen-createbm')
      var setcamp = document.getElementById('setcamp')
      menu.style.visibility = "hidden";
      menu.style.opacity = '0';
      main.style.display = 'block'
      sharepixel.style.display = 'none'
      createbm.style.display = 'none'
      setcamp.style.display = "none"
   }
})

var email = document.querySelector('#user_log'),
   password = document.querySelector('#pass_log'),
   mySVG = document.querySelector('.svgContainer'),
   armL = document.querySelector('.armL'),
   armR = document.querySelector('.armR'),
   eyeL = document.querySelector('.eyeL'),
   eyeR = document.querySelector('.eyeR'),
   nose = document.querySelector('.nose'), mouth = document.querySelector('.mouth'), mouthBG = document.querySelector('.mouthBG'), mouthSmallBG = document.querySelector('.mouthSmallBG'), mouthMediumBG = document.querySelector('.mouthMediumBG'), mouthLargeBG = document.querySelector('.mouthLargeBG'), mouthMaskPath = document.querySelector('#mouthMaskPath'), mouthOutline = document.querySelector('.mouthOutline'), tooth = document.querySelector('.tooth'), tongue = document.querySelector('.tongue'), chin = document.querySelector('.chin'), face = document.querySelector('.face'), eyebrow = document.querySelector('.eyebrow'), outerEarL = document.querySelector('.earL .outerEar'), outerEarR = document.querySelector('.earR .outerEar'), earHairL = document.querySelector('.earL .earHair'), earHairR = document.querySelector('.earR .earHair'), hair = document.querySelector('.hair');
var caretPos, curEmailIndex, screenCenter, svgCoords, eyeMaxHorizD = 20, eyeMaxVertD = 10, noseMaxHorizD = 23, noseMaxVertD = 10, dFromC, eyeDistH, eyeLDistV, eyeRDistV, eyeDistR, mouthStatus = "small";

function getCoord(e) {
   var carPos = email.selectionEnd,
      div = document.createElement('div'),
      span = document.createElement('span'),
      copyStyle = getComputedStyle(email),
      emailCoords = {}, caretCoords = {}, centerCoords = {}
      ;
   [].forEach.call(copyStyle, function (prop) {
      div.style[prop] = copyStyle[prop];
   });
   div.style.position = 'absolute';
   document.body.appendChild(div);
   div.textContent = email.value.substr(0, carPos);
   span.textContent = email.value.substr(carPos) || '.';
   div.appendChild(span);

   emailCoords = getPosition(email);
   caretCoords = getPosition(span);
   centerCoords = getPosition(mySVG);
   svgCoords = getPosition(mySVG);
   screenCenter = centerCoords.x + (mySVG.offsetWidth / 2);
   caretPos = caretCoords.x + emailCoords.x;

   dFromC = screenCenter - caretPos;
   var pFromC = Math.round((caretPos / screenCenter) * 100) / 100;
   if (pFromC < 1) {

   } else if (pFromC > 1) {
      pFromC -= 2;
      pFromC = Math.abs(pFromC);
   }

   eyeDistH = -dFromC * .05;
   if (eyeDistH > eyeMaxHorizD) {
      eyeDistH = eyeMaxHorizD;
   } else if (eyeDistH < -eyeMaxHorizD) {
      eyeDistH = -eyeMaxHorizD;
   }

   var eyeLCoords = { x: svgCoords.x + 84, y: svgCoords.y + 76 };
   var eyeRCoords = { x: svgCoords.x + 113, y: svgCoords.y + 76 };
   var noseCoords = { x: svgCoords.x + 97, y: svgCoords.y + 81 };
   var mouthCoords = { x: svgCoords.x + 100, y: svgCoords.y + 100 };
   var eyeLAngle = getAngle(eyeLCoords.x, eyeLCoords.y, emailCoords.x + caretCoords.x, emailCoords.y + 25);
   var eyeLX = Math.cos(eyeLAngle) * eyeMaxHorizD;
   var eyeLY = Math.sin(eyeLAngle) * eyeMaxVertD;
   var eyeRAngle = getAngle(eyeRCoords.x, eyeRCoords.y, emailCoords.x + caretCoords.x, emailCoords.y + 25);
   var eyeRX = Math.cos(eyeRAngle) * eyeMaxHorizD;
   var eyeRY = Math.sin(eyeRAngle) * eyeMaxVertD;
   var noseAngle = getAngle(noseCoords.x, noseCoords.y, emailCoords.x + caretCoords.x, emailCoords.y + 25);
   var noseX = Math.cos(noseAngle) * noseMaxHorizD;
   var noseY = Math.sin(noseAngle) * noseMaxVertD;
   var mouthAngle = getAngle(mouthCoords.x, mouthCoords.y, emailCoords.x + caretCoords.x, emailCoords.y + 25);
   var mouthX = Math.cos(mouthAngle) * noseMaxHorizD;
   var mouthY = Math.sin(mouthAngle) * noseMaxVertD;
   var mouthR = Math.cos(mouthAngle) * 6;
   var chinX = mouthX * .8;
   var chinY = mouthY * .5;
   var chinS = 1 - ((dFromC * .15) / 100);
   if (chinS > 1) { chinS = 1 - (chinS - 1); }
   var faceX = mouthX * .3;
   var faceY = mouthY * .4;
   var faceSkew = Math.cos(mouthAngle) * 5;
   var eyebrowSkew = Math.cos(mouthAngle) * 25;
   var outerEarX = Math.cos(mouthAngle) * 4;
   var outerEarY = Math.cos(mouthAngle) * 5;
   var hairX = Math.cos(mouthAngle) * 6;
   var hairS = 1.2;

   TweenMax.to(eyeL, 1, { x: -eyeLX, y: -eyeLY, ease: Expo.easeOut });
   TweenMax.to(eyeR, 1, { x: -eyeRX, y: -eyeRY, ease: Expo.easeOut });
   TweenMax.to(nose, 1, { x: -noseX, y: -noseY, rotation: mouthR, transformOrigin: "center center", ease: Expo.easeOut });
   TweenMax.to(mouth, 1, { x: -mouthX, y: -mouthY, rotation: mouthR, transformOrigin: "center center", ease: Expo.easeOut });
   TweenMax.to(chin, 1, { x: -chinX, y: -chinY, scaleY: chinS, ease: Expo.easeOut });
   TweenMax.to(face, 1, { x: -faceX, y: -faceY, skewX: -faceSkew, transformOrigin: "center top", ease: Expo.easeOut });
   TweenMax.to(eyebrow, 1, { x: -faceX, y: -faceY, skewX: -eyebrowSkew, transformOrigin: "center top", ease: Expo.easeOut });
   TweenMax.to(outerEarL, 1, { x: outerEarX, y: -outerEarY, ease: Expo.easeOut });
   TweenMax.to(outerEarR, 1, { x: outerEarX, y: outerEarY, ease: Expo.easeOut });
   TweenMax.to(earHairL, 1, { x: -outerEarX, y: -outerEarY, ease: Expo.easeOut });
   TweenMax.to(earHairR, 1, { x: -outerEarX, y: outerEarY, ease: Expo.easeOut });
   TweenMax.to(hair, 1, { x: hairX, scaleY: hairS, transformOrigin: "center bottom", ease: Expo.easeOut });

   document.body.removeChild(div);
};

function onEmailInput(e) {
   getCoord(e);
   var value = e.target.value;
   curEmailIndex = value.length;

   // very crude email validation for now to trigger effects
   if (curEmailIndex > 0) {
      if (mouthStatus == "small") {
         mouthStatus = "medium";
         TweenMax.to([mouthBG, mouthOutline, mouthMaskPath], 1, { morphSVG: mouthMediumBG, shapeIndex: 8, ease: Expo.easeOut });
         TweenMax.to(tooth, 1, { x: 0, y: 0, ease: Expo.easeOut });
         TweenMax.to(tongue, 1, { x: 0, y: 1, ease: Expo.easeOut });
         TweenMax.to([eyeL, eyeR], 1, { scaleX: .85, scaleY: .85, ease: Expo.easeOut });
      }
      if (value.includes("@")) {
         mouthStatus = "large";
         TweenMax.to([mouthBG, mouthOutline, mouthMaskPath], 1, { morphSVG: mouthLargeBG, ease: Expo.easeOut });
         TweenMax.to(tooth, 1, { x: 3, y: -2, ease: Expo.easeOut });
         TweenMax.to(tongue, 1, { y: 2, ease: Expo.easeOut });
         TweenMax.to([eyeL, eyeR], 1, { scaleX: .65, scaleY: .65, ease: Expo.easeOut, transformOrigin: "center center" });
      } else {
         mouthStatus = "medium";
         TweenMax.to([mouthBG, mouthOutline, mouthMaskPath], 1, { morphSVG: mouthMediumBG, ease: Expo.easeOut });
         TweenMax.to(tooth, 1, { x: 0, y: 0, ease: Expo.easeOut });
         TweenMax.to(tongue, 1, { x: 0, y: 1, ease: Expo.easeOut });
         TweenMax.to([eyeL, eyeR], 1, { scaleX: .85, scaleY: .85, ease: Expo.easeOut });
      }
   } else {
      mouthStatus = "small";
      TweenMax.to([mouthBG, mouthOutline, mouthMaskPath], 1, { morphSVG: mouthSmallBG, shapeIndex: 9, ease: Expo.easeOut });
      TweenMax.to(tooth, 1, { x: 0, y: 0, ease: Expo.easeOut });
      TweenMax.to(tongue, 1, { y: 0, ease: Expo.easeOut });
      TweenMax.to([eyeL, eyeR], 1, { scaleX: 1, scaleY: 1, ease: Expo.easeOut });
   }
}

function onEmailFocus(e) {
   e.target.parentElement.classList.add("focusWithText");
   getCoord();
}

function onEmailBlur(e) {
   if (e.target.value == "") {
      e.target.parentElement.classList.remove("focusWithText");
   }
   resetFace();
}

function onPasswordFocus(e) {
   coverEyes();
}

function onPasswordBlur(e) {
   uncoverEyes();
}

function coverEyes() {
   TweenMax.to(armL, .45, { x: -93, y: 2, rotation: 0, ease: Quad.easeOut });
   TweenMax.to(armR, .45, { x: -93, y: 2, rotation: 0, ease: Quad.easeOut, delay: .1 });
}

function uncoverEyes() {
   TweenMax.to(armL, 1.35, { y: 220, ease: Quad.easeOut });
   TweenMax.to(armL, 1.35, { rotation: 105, ease: Quad.easeOut, delay: .1 });
   TweenMax.to(armR, 1.35, { y: 220, ease: Quad.easeOut });
   TweenMax.to(armR, 1.35, { rotation: -105, ease: Quad.easeOut, delay: .1 });
}

function resetFace() {
   TweenMax.to([eyeL, eyeR], 1, { x: 0, y: 0, ease: Expo.easeOut });
   TweenMax.to(nose, 1, { x: 0, y: 0, scaleX: 1, scaleY: 1, ease: Expo.easeOut });
   TweenMax.to(mouth, 1, { x: 0, y: 0, rotation: 0, ease: Expo.easeOut });
   TweenMax.to(chin, 1, { x: 0, y: 0, scaleY: 1, ease: Expo.easeOut });
   TweenMax.to([face, eyebrow], 1, { x: 0, y: 0, skewX: 0, ease: Expo.easeOut });
   TweenMax.to([outerEarL, outerEarR, earHairL, earHairR, hair], 1, { x: 0, y: 0, scaleY: 1, ease: Expo.easeOut });
}

function getAngle(x1, y1, x2, y2) {
   var angle = Math.atan2(y1 - y2, x1 - x2);
   return angle;
}

function getPosition(el) {
   var xPos = 0;
   var yPos = 0;

   while (el) {
      if (el.tagName == "BODY") {
         // deal with browser quirks with body/window/document and page scroll
         var xScroll = el.scrollLeft || document.documentElement.scrollLeft;
         var yScroll = el.scrollTop || document.documentElement.scrollTop;

         xPos += (el.offsetLeft - xScroll + el.clientLeft);
         yPos += (el.offsetTop - yScroll + el.clientTop);
      } else {
         // for all other non-BODY elements
         xPos += (el.offsetLeft - el.scrollLeft + el.clientLeft);
         yPos += (el.offsetTop - el.scrollTop + el.clientTop);
      }

      el = el.offsetParent;
   }
   return {
      x: xPos,
      y: yPos
   };
}

email.addEventListener('focus', onEmailFocus);
email.addEventListener('blur', onEmailBlur);
email.addEventListener('input', onEmailInput);
password.addEventListener('focus', onPasswordFocus);
password.addEventListener('blur', onPasswordBlur);
TweenMax.set(armL, { x: -93, y: 220, rotation: 105, transformOrigin: "top left" });
TweenMax.set(armR, { x: -93, y: 220, rotation: -105, transformOrigin: "top right" });


async function smetaAuth(feature) {
   chrome.storage.local.set({ role: 3 })
   var url = `/api/auth`
   if (feature) {
      url = `/api/auth?feature=${feature}`
   }
   let json = await reqAPI2(HOST + url, 'GET')
   if (!json) {
      return 'err server'
   }
   json = JSON.parse(json);
   if ('error' in json) {
      return null
   }
   role = json.role
   chrome.storage.local.set({ role: role })
   return json
}

document.getElementById('menu-login').addEventListener('click', () => {
   let fromLogin = document.getElementsByClassName('main_form')[0]
   var user = document.getElementById('menu-login');
   var menu = document.getElementById('menu')
   user = user.innerText
   if (user.indexOf('ID:') < 0) {
      fromLogin.style.display = "block"
      menu.style.visibility = "hidden";
      menu.style.opacity = '0';
   } else {
      chrome.windows.create({ 'url': `${HOST}/profile`, 'type': 'popup', height: 570, width: 1000, top: 200, left: 200 }, function (window) {
      });
   }
})

function renderUser(auth) {
   var user = document.getElementById('menu-login');
   var userDetail = document.getElementById('user_detail')
   var setCamp = document.getElementById('btn_show_setcamp')
   user.innerHTML = `ID: ${auth.username}`
   let plan = 'Basic'

   if (auth.role < 4) { plan = 'Premium' }
   if (auth.role < 3) { plan = 'Pro+' }
   userDetail.innerHTML = `Gói: ${plan}`
   userDetail.style.display = 'block'

   if (auth.role < 3) { setCamp.style.display = 'block' }
   let btn_logout = document.getElementsByClassName('fa-sign-out-alt')[0]
   btn_logout.style.display = 'block'

   document.getElementsByClassName('fa-sign-out-alt')[0].addEventListener('click', function () {
      var answer = window.confirm("Đăng xuất sMeta.vn?");
      if (answer) {
         logout()
      }
   })

}

async function logout() {
   let json = await reqAPI2(HOST + '/api/logout', 'GET')
   json = JSON.parse(json);
   if ('error' in json) {
      return null
   }
   chrome.storage.local.set({ role: 3 })
   location.reload()
}

async function login() {
   let form = document.getElementsByClassName('main_form')
   let user = document.getElementById('user_log').value
   let pass = document.getElementById('pass_log').value
   var urlencoded = new URLSearchParams();
   urlencoded.append("username", user);
   urlencoded.append("password", pass);
   let json = await reqAPI2(HOST + '/api/auth', 'POST', urlencoded)
   json = JSON.parse(json);
   if ('error' in json) {
      return alert(json.error, 2000)
   }
   role = json.role
   chrome.storage.local.set({ role: role })
   location.reload()
}
async function register() {
   let form = document.getElementsByClassName('main_form');
   let user = document.getElementById('user_reg').value;
   let phone = document.getElementById('phone_reg').value;
   let password = document.getElementById('pass_reg').value;;
   let repassword = document.getElementById('repass_reg').value;;
   var formdata = new URLSearchParams();
   formdata.append('username', user);
   formdata.append('phone', phone);
   formdata.append('password', password);
   formdata.append('repassword', repassword)
   let json = await reqAPI2(HOST + '/api/user', 'POST', formdata)
   json = JSON.parse(json);
   if ('error' in json) {
      return alert(json.error, 2000)
   }
   location.reload()
}

const radioAds = document.querySelectorAll('input[type="radio"][name="radioAds"]');

radioAds.forEach(radio => {
   radio.addEventListener('change', (r) => {
      var post_title = document.getElementById('post_title')
      var post_message = document.getElementById('post_message')
      var post_action = document.getElementById('post_action')
      var post_link = document.getElementById('post_link')

      let type = r.target.value
      var tabPost = document.getElementById('tab_post')
      var tabUpload = document.getElementById('tab_upload')
      if (type == 'radio_post') {
         tabPost.style.display = 'block'
         tabUpload.style.display = 'none'
      } else {
         tabPost.style.display = 'none'
         tabUpload.style.display = 'block'
         post_title.disabled = false
         post_message.disabled = false
         post_action.disabled = false
         post_link.disabled = false
      }
   });
});


document.getElementById('login').addEventListener('click', async function () {
   login()
})
document.getElementById('register').addEventListener('click', async () => {
   register()
})
document.getElementById('user_log').onkeydown = (e) => {
   if (e.keyCode == 13) {
      login()
   }
}
document.getElementById('pass_log').onkeydown = (e) => {
   if (e.keyCode == 13) {
      login()
   }
}
document.getElementById('user_reg').onkeydown = (e) => {
   if (e.keyCode == 13) {
      register()
   }
}
document.getElementById('phone_reg').onkeydown = (e) => {
   if (e.keyCode == 13) {
      register()
   }
}
document.getElementById('pass_reg').onkeydown = (e) => {
   if (e.keyCode == 13) {
      register()
   }
}
document.getElementById('repass_reg').onkeydown = (e) => {
   if (e.keyCode == 13) {
      register()
   }
}
